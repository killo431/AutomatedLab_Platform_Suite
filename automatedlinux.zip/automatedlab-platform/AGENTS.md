# AGENTS.md — AutomatedLab Platform

Guidance for AI agents working in this repository.

## What this is

A Lab-as-a-Service (LaaS) platform: Hyper-V + ReFS block-cloning, AutomatedLab,
PowerShell Universal (PSU), Apache Guacamole (HTML5 console), Docker Compose,
and Keeper Security secret escrow.

## Layout

- `Fast-Setup.ps1` — bare-metal bootstrap (Hyper-V, storage, AutomatedLab MSI, PSU, Guacamole, web frontend).
- `setup/` — `Build-Platform.ps1` (orchestrator + auto-resume), `Install-Prerequisites.ps1`, `Install-PowerShell7.ps1`.
- `scripts/` — 01 storage · 02 Guacamole injector · 03 app delivery · 04 Compose/Keeper generator (Python) · 05 reaper · 06 lease registry · 07 PSU REST endpoints · 08 smoke test.
- `configs/`, `templates/`, `docs/` — compose/config/spec.
- `docker/` — containerized control plane (Caddy + PSU + Guacamole).
- `linux/` — Linux install/deploy/lab scripts (`install.sh`, `deploy.sh`, `setup.sh`, `uninstall.sh`, `lab.sh`).
- `tofu/` — OpenTofu provisioning engine (`graph_to_hcl.py`, base-image guide).
- `AUTOMATElab/` — static landing dashboard (HTML/CSS/JS).
- `web/` — React/Vite no-code canvas (spec M1).

## Key facts / gotchas

- PowerShell 7.4+ and **AutomatedLab 5.58+ installed from MSI** are required (MSI ships worker binaries).
- AutomatedLab v5 uses `New-LabSourcesFolder -DriveLetter <L>` — **not** `Set-LabConfiguration`.
- Windows 11 Pro **cannot create ReFS**; use the NTFS fallback (`-AllocationUnitSize 65536`).
- Guacamole images are Linux-only; `Fast-Setup.ps1` detects `docker info --format '{{.OSType}}'`.
- The Compose/Keeper generator (`scripts/04_*.py`) is stdlib-only; the Keeper folder path must be a **single** backslash (use `chr(92)`).
- Hyper-V/WSL2 enablement needs a reboot; `Build-Platform.ps1` registers an elevated auto-resume scheduled task.
- ReFS block-cloning only works on Windows Server / Pro for Workstations.

## Common commands

```powershell
.\setup\Build-Platform.ps1 -AutoReboot     # full bootstrap (reboot + auto-resume)
.\scripts\08_Smoke_Test.ps1                # go/no-go verification
```

```bash
cd web && npm install && npm run dev       # React/Vite M1 canvas
cd docker && docker compose up -d          # containerized control plane
```

## Conventions

- Scripts are idempotent and safe to re-run.
- Secrets live only in templates/`.env.example`; never commit real credentials.
- PowerShell scripts target both Windows PowerShell 5.1 and PowerShell 7 where possible.
