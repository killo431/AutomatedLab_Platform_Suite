// AUTOMATElab landing dashboard.
// Talks to the PowerShell Universal endpoints registered by
// scripts/07_Register_WebFrontend_Endpoints.ps1.

const API = {
  status: '/api/v1/automatelab/status',
  labs: '/api/v1/automatelab/labs',
};

function el(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstChild;
}

async function fetchJson(url) {
  const res = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return res.json();
}

function renderStatus(s) {
  const map = {
    hyperv: s.hyperv ? 'online' : 'offline',
    docker: s.docker ? 'online' : 'offline',
    guacamole: s.guacamole ? 'online' : 'offline',
  };
  document.querySelectorAll('#statusPills .pill').forEach((p) => {
    const key = p.dataset.key;
    const state = map[key];
    p.className = 'pill ' + (state === 'online' ? 'ok' : 'warn');
    p.innerHTML = (key[0].toUpperCase() + key.slice(1)) + ' &middot; ' + state;
  });
}

function renderLabs(labs) {
  const list = document.getElementById('labList');
  list.innerHTML = '';
  if (!labs || !labs.length) {
    list.innerHTML = '<p class="muted">No labs defined yet.</p>';
    return;
  }
  labs.forEach((lab) => {
    const expiry = lab.expiresAt ? new Date(lab.expiresAt).toLocaleString() : 'n/a';
    list.appendChild(el(`
      <div class="lab-card">
        <div>
          <div class="lab-name">${lab.name}</div>
          <div class="lab-meta">expires ${expiry}</div>
        </div>
        <button class="btn btn-sm" data-console="${lab.name}">Console</button>
      </div>
    `));
  });
}

async function refresh() {
  const log = document.getElementById('logLine');
  try {
    const status = await fetchJson(API.status);
    renderStatus(status);
    document.getElementById('telemetry').textContent = JSON.stringify(status, null, 2);
    log.textContent = 'Host ' + status.host +
      ' &middot; Hyper-V ' + (status.hyperv ? 'on' : 'off') +
      ' &middot; Docker ' + (status.docker ? 'on' : 'off');
  } catch (e) {
    log.textContent = 'Backend offline — ensure PowerShell Universal is running.';
    document.getElementById('telemetry').textContent = 'API unreachable: ' + e.message;
  }

  try {
    renderLabs(await fetchJson(API.labs));
  } catch (e) {
    document.getElementById('labList').innerHTML = '<p class="muted">Labs endpoint unavailable.</p>';
  }
}

document.getElementById('btnStudio').addEventListener('click', () => window.open('/automatedlab', '_blank'));
document.getElementById('btnConsole').addEventListener('click', () => window.open('/guacamole', '_blank'));
document.getElementById('labList').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-console]');
  if (btn) window.open('/guacamole', '_blank');
});

refresh();
setInterval(refresh, 10000);
