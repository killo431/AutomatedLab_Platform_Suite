<#
.SYNOPSIS
    AutomatedLab & PowerShell Universal Platform Fast Setup Script.
.DESCRIPTION
    Automated, idempotent bootstrap for Windows Server 2022/2025 and Windows 11 Pro/Enterprise.
    - Enables Hyper-V + PSRemoting and handles the required reboot
    - Initializes fast storage: ReFS (64KB) with automatic NTFS fallback on editions that
      cannot create ReFS (e.g. Windows 11 Pro, which lacks ReFS creation)
    - Installs the AutomatedLab module suite, Pester 5, and PowerShell Universal
    - Deploys the Apache Guacamole HTML5 gateway (Linux containers, auto-detected)
.PARAMETER TargetDiskNumber
    Disk number of the fast disk to format (default 1).
.PARAMETER StorageDriveLetter
    Drive letter assigned to the storage root (default V).
.PARAMETER SkipDiskFormat
    Skip formatting and use an existing volume/directory.
.PARAMETER DeployGuacamole
    Deploy the Guacamole gateway via Docker Compose (default true).
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [int]$TargetDiskNumber = 1,

    [Parameter(Mandatory = $false)]
    [string]$StorageDriveLetter = "V",

    [Parameter(Mandatory = $false)]
    [switch]$SkipDiskFormat,

    [Parameter(Mandatory = $false)]
    [bool]$DeployGuacamole = $true
)

$ErrorActionPreference = "Stop"
$rebootRequired = $false

Write-Host "====================================================================" -ForegroundColor Cyan
Write-Host " AutomatedLab & PowerShell Universal Enterprise Platform Fast Setup " -ForegroundColor Cyan
Write-Host "====================================================================" -ForegroundColor Cyan

# 0. Environment detection
$osInfo = Get-CimInstance Win32_OperatingSystem
Write-Host "[-] Detected: $($osInfo.Caption) ($($osInfo.Version))" -ForegroundColor DarkGray
if ($osInfo.ProductType -eq 1) {
    Write-Host "  [i] Client OS detected. ReFS creation is unavailable on Windows 11 Pro/Home; NTFS will be used if needed." -ForegroundColor DarkGray
}

# 1. Privilege & Execution Policy Check
$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $IsAdmin) {
    throw "Fast-Setup.ps1 must be executed in an elevated Administrator PowerShell prompt."
}

Write-Host "[-] Configuring PowerShell Execution Policy..." -ForegroundColor Yellow
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope LocalMachine -Force

# 2. Hyper-V & PSRemoting Setup
Write-Host "[-] Verifying Hyper-V and Remote Management Features..." -ForegroundColor Yellow
$hypervisorPresent = (Get-CimInstance Win32_ComputerSystem).HypervisorPresent
$hyperVFeature = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-Hypervisor -ErrorAction SilentlyContinue

if (-not $hypervisorPresent) {
    if (-not $hyperVFeature -or $hyperVFeature.State -ne "Enabled") {
        Write-Host "  [+] Enabling Hyper-V features (a reboot will be required)..." -ForegroundColor Yellow
        Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All -NoRestart | Out-Null
    } else {
        Write-Host "  [+] Hyper-V is enabled but the hypervisor is not active yet (reboot required)." -ForegroundColor Yellow
    }
    $rebootRequired = $true
} else {
    Write-Host "  [OK] Hyper-V hypervisor is running." -ForegroundColor Green
}

Enable-PSRemoting -Force -SkipNetworkProfileCheck | Out-Null
Set-Service -Name WinRM -StartupType Automatic
Start-Service -Name WinRM -ErrorAction SilentlyContinue

# 3. Fast storage initialization (ReFS 64KB, with NTFS fallback)
$StorageRoot = "$StorageDriveLetter`:"
$storageFs = "unknown"
if (-not $SkipDiskFormat) {
    Write-Host "[-] Initializing dedicated fast storage on Disk $TargetDiskNumber..." -ForegroundColor Yellow
    try {
        Initialize-Disk -Number $TargetDiskNumber -PartitionStyle GPT -ErrorAction SilentlyContinue
        Set-Disk -Number $TargetDiskNumber -IsOffline $false -IsReadOnly $false
        $null = New-Partition -DiskNumber $TargetDiskNumber -UseMaximumSize -DriveLetter $StorageDriveLetter

        try {
            Format-Volume -DriveLetter $StorageDriveLetter -FileSystem ReFS -AllocationUnitSize 65536 -NewFileSystemLabel "Lab_FastStorage" -Confirm:$false | Out-Null
            $storageFs = "ReFS"
            Write-Host "  [OK] $StorageRoot formatted with ReFS (64KB block cloning)." -ForegroundColor Green
        } catch {
            Write-Warning "ReFS creation is not available on this Windows edition (e.g. Windows 11 Pro)."
            Write-Warning "Falling back to NTFS. ReFS block cloning will be unavailable; use Pro for Workstations or Server for ReFS."
            Format-Volume -DriveLetter $StorageDriveLetter -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "Lab_FastStorage" -Confirm:$false | Out-Null
            $storageFs = "NTFS"
            Write-Host "  [OK] $StorageRoot formatted with NTFS (64KB)." -ForegroundColor Yellow
        }
    } catch {
        Write-Warning "Disk initialization failed or the disk is already formatted: $_. Reusing the existing volume."
    }
} else {
    Write-Host "[-] Skipping disk formatting as requested. Using $StorageRoot." -ForegroundColor Yellow
}

if ($storageFs -eq "unknown") {
    $vol = Get-Volume -DriveLetter $StorageDriveLetter -ErrorAction SilentlyContinue
    if ($vol) { $storageFs = $vol.FileSystem }
}

if (-not (Test-Path $StorageRoot)) {
    throw "Storage root $StorageRoot is not available. Attach/select a valid disk with -TargetDiskNumber, or use -SkipDiskFormat with an existing volume."
}

# Configure Hyper-V default VM paths (requires the hypervisor to be running)
$VhdPath = "$StorageRoot\Hyper-V\Virtual Hard Disks"
$VmPath  = "$StorageRoot\Hyper-V\Virtual Machines"
New-Item -Path $VhdPath -ItemType Directory -Force | Out-Null
New-Item -Path $VmPath  -ItemType Directory -Force | Out-Null

$hyperVReady = $hypervisorPresent -and (Get-Module -ListAvailable -Name Hyper-V -ErrorAction SilentlyContinue)
if (-not $hyperVReady) {
    Write-Warning "Hyper-V is not fully active yet; skipping Set-VMHost. Re-run after reboot to apply VM paths."
    $rebootRequired = $true
} else {
    try {
        Set-VMHost -VirtualHardDiskPath $VhdPath -VirtualMachinePath $VmPath -ErrorAction Stop
        Write-Host "  [OK] Hyper-V VM paths set to $StorageRoot\Hyper-V" -ForegroundColor Green
    } catch {
        Write-Warning "Set-VMHost failed: $_"
    }
}

# 4. LabSources Directory Structure
Write-Host "[-] Structuring LabSources repository on fast storage..." -ForegroundColor Yellow
$LabSourcesRoot = "$StorageRoot\LabSources"
$Folders = @(
    "$LabSourcesRoot\ISOs",
    "$LabSourcesRoot\SoftwarePackages",
    "$LabSourcesRoot\Tools",
    "$LabSourcesRoot\CustomUploads",
    "$LabSourcesRoot\DockerTemplates"
)
foreach ($Folder in $Folders) {
    if (-not (Test-Path $Folder)) {
        New-Item -Path $Folder -ItemType Directory -Force | Out-Null
    }
}
Write-Host "  [OK] LabSources configured at $LabSourcesRoot" -ForegroundColor Green

# 5. AutomatedLab Module Suite Installation
Write-Host "[-] Installing AutomatedLab and dependencies..." -ForegroundColor Yellow
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if (-not (Get-PackageProvider -Name NuGet -ListAvailable -ErrorAction SilentlyContinue)) {
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force | Out-Null
}

# Install the full AutomatedLab MSI (required by the web Studio and worker binaries).
# The MSI ships binaries the PowerShell Gallery modules alone do not include.
$alInstalled = Get-Module -ListAvailable -Name AutomatedLab | Sort-Object Version -Descending | Select-Object -First 1
if (-not $alInstalled -or $alInstalled.Version -lt [version]"5.58.0") {
    Write-Host "  [+] Installing AutomatedLab from MSI (full installer)..." -ForegroundColor Cyan
    try {
        $release = Invoke-RestMethod -Uri "https://api.github.com/repos/AutomatedLab/AutomatedLab/releases/latest" -Headers @{ "User-Agent" = "AutomatedLab-Setup" }
        $msiAsset = $release.assets | Where-Object { $_.name -eq "AutomatedLab.msi" } | Select-Object -First 1
        if ($msiAsset) {
            $msiPath = Join-Path $env:TEMP "AutomatedLab.msi"
            Invoke-WebRequest -Uri $msiAsset.browser_download_url -OutFile $msiPath -UseBasicParsing
            $p = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$msiPath`" /qn /norestart" -Wait -PassThru
            if ($p.ExitCode -notin @(0, 3010)) { throw "AutomatedLab MSI install failed with exit code $($p.ExitCode)." }
            Write-Host "  [OK] AutomatedLab MSI installed." -ForegroundColor Green
        } else {
            Write-Warning "Could not locate AutomatedLab.msi in the latest release; falling back to PowerShell Gallery."
        }
    } catch {
        Write-Warning "AutomatedLab MSI install failed: $_. Falling back to PowerShell Gallery modules."
    }
}

$Modules = @("AutomatedLab", "AutomatedLab.Common", "AutomatedLab.Core", "AutomatedLab.Definition", "AutomatedLab.Worker")
foreach ($Mod in $Modules) {
    if (-not (Get-Module -ListAvailable -Name $Mod)) {
        Write-Host "  [+] Installing module $Mod..." -ForegroundColor Cyan
        Install-Module -Name $Mod -Scope AllUsers -Force -SkipPublisherCheck | Out-Null
    } else {
        Write-Host "  [OK] Module $Mod is already installed." -ForegroundColor Green
    }
}

# Pester 5+ powers AutomatedLab's optional post-deployment tests (Windows ships Pester 3.4).
if (-not (Get-Module -ListAvailable -Name Pester | Where-Object { $_.Version.Major -ge 5 })) {
    Write-Host "  [+] Installing Pester 5..." -ForegroundColor Cyan
    Install-Module -Name Pester -Scope AllUsers -Force -SkipPublisherCheck -AllowClobber | Out-Null
} else {
    Write-Host "  [OK] Pester 5+ is available." -ForegroundColor Green
}

Import-Module AutomatedLab -Force

# Register the LabSources location (AutomatedLab v5 manages config via PSFramework).
try {
    New-LabSourcesFolder -DriveLetter $StorageDriveLetter -ErrorAction Stop | Out-Null
    Write-Host "  [OK] AutomatedLab LabSources location registered at $LabSourcesRoot" -ForegroundColor Green
} catch {
    Write-Warning "Could not register LabSources with AutomatedLab: $_"
    Write-Warning "Run 'New-LabSourcesFolder -DriveLetter $StorageDriveLetter' manually after setup."
}

# 6. PowerShell Universal Installation
Write-Host "[-] Installing PowerShell Universal (PSU) Management Service..." -ForegroundColor Yellow
if (-not (Get-Module -ListAvailable -Name PowerShellUniversal)) {
    Install-Module -Name PowerShellUniversal -Scope AllUsers -Force -SkipPublisherCheck | Out-Null
}

Import-Module PowerShellUniversal -Force -ErrorAction SilentlyContinue

if (-not (Get-Command Install-PSUServer -ErrorAction SilentlyContinue)) {
    Write-Warning "PowerShellUniversal module could not be loaded; skipping PSU service registration."
    Write-Warning "Run 'Install-PSUServer -InstallDirectory \"C:\Program Files\PowerShell Universal\" -Service' manually."
} elseif (-not (Get-Service -Name "PowerShellUniversal" -ErrorAction SilentlyContinue)) {
    Write-Host "  [+] Registering PowerShell Universal as a Windows Service..." -ForegroundColor Cyan
    Install-PSUServer -InstallDirectory "C:\Program Files\PowerShell Universal" -Service
    Start-Service -Name "PowerShellUniversal"
    Write-Host "  [OK] PowerShell Universal service started." -ForegroundColor Green
} else {
    Restart-Service -Name "PowerShellUniversal"
    Write-Host "  [OK] PowerShell Universal service is running." -ForegroundColor Green
}

# 7. Guacamole Gateway Deployment (Linux containers only)
if ($DeployGuacamole) {
    Write-Host "[-] Deploying Apache Guacamole HTML5 Gateway..." -ForegroundColor Yellow
    if (Get-Command docker -ErrorAction SilentlyContinue) {
        $dockerOsType = $null
        $dockerDeadline = (Get-Date).AddSeconds(60)
        do {
            try {
                $raw = docker info --format '{{.OSType}}' 2>$null
                if ($raw) { $dockerOsType = ([string]$raw).Trim() }
            } catch {
                $dockerOsType = $null
            }
            if (-not $dockerOsType) { Start-Sleep -Seconds 5 }
        } while (-not $dockerOsType -and (Get-Date) -lt $dockerDeadline)

        if ($dockerOsType -eq 'linux') {
            $GuacDir = "$StorageRoot\GuacamoleGateway"
            New-Item -Path $GuacDir -ItemType Directory -Force | Out-Null
            New-Item -Path "$GuacDir\init" -ItemType Directory -Force | Out-Null
            Copy-Item -Path "$PSScriptRoot\configs\docker-compose.guacamole.yml" -Destination "$GuacDir\docker-compose.yml" -Force

            # Generate a strong random DB password (no hardcoded fallback) and provide it via .env.
            $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
            $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'
            $guacPassword = -join (1..24 | ForEach-Object {
                $b = New-Object byte 1
                $rng.GetBytes($b)
                $chars[$b[0] % $chars.Length]
            })
            Set-Content -Path "$GuacDir\.env" -Value "GUACAMOLE_DB_PASSWORD=$guacPassword" -Encoding ASCII

            Push-Location $GuacDir
            try {
                docker compose up -d
                if ($LASTEXITCODE -eq 0) {
                    Write-Host "  [OK] Guacamole web gateway is live on http://localhost:8443/guacamole" -ForegroundColor Green
                    Write-Warning "Guacamole default admin is guacadmin/guacadmin — change it immediately in the Guacamole UI."
                } else {
                    Write-Warning "docker compose up returned exit code $LASTEXITCODE. Check 'docker compose logs' in '$GuacDir'."
                }
            } finally {
                Pop-Location
            }
        } elseif ($dockerOsType -eq 'windows') {
            Write-Warning "Docker is in Windows container mode, but the Guacamole stack requires Linux containers."
            Write-Warning "Skipping Guacamole. Enable Linux containers (Docker Desktop > WSL 2 based engine) and re-run."
        } else {
            Write-Warning "Could not determine the Docker container OS (is the Docker daemon running?). Skipping Guacamole."
        }
    } else {
        Write-Warning "Docker is not installed. Install Docker Desktop (Windows 11) or Docker Engine, then re-run to deploy Guacamole."
    }
}

# 8. Web Frontend (AutomatedLab Studio + AUTOMATElab dashboard)
Write-Host "[-] Installing AutomatedLab web frontend..." -ForegroundColor Yellow
$webModules = @("AutomatedLab.Utils", "Configuration", "PowerShellUniversal.Apps.AutomatedLab")
foreach ($Mod in $webModules) {
    if (-not (Get-Module -ListAvailable -Name $Mod)) {
        Write-Host "  [+] Installing module $Mod..." -ForegroundColor Cyan
        Install-Module -Name $Mod -Scope AllUsers -Force -SkipPublisherCheck | Out-Null
    } else {
        Write-Host "  [OK] Module $Mod already installed." -ForegroundColor Green
    }
}

# Deploy the PSU app into PowerShell Universal's repository so it auto-loads at /automatedlab.
$appModule = Get-Module -ListAvailable -Name PowerShellUniversal.Apps.AutomatedLab | Sort-Object Version -Descending | Select-Object -First 1
if ($appModule) {
    $appModuleBase = if ($appModule.ModuleBase) { $appModule.ModuleBase } elseif ($appModule.Path) { Split-Path $appModule.Path -Parent } else { $null }
    if ($appModuleBase) {
        $psuRepoModules = "C:\ProgramData\UniversalAutomation\Repository\Modules"
        $appDest = Join-Path $psuRepoModules "PowerShellUniversal.Apps.AutomatedLab"
        if (-not (Test-Path $appDest)) {
            New-Item -ItemType Directory -Path $psuRepoModules -Force | Out-Null
            Copy-Item -Path $appModuleBase -Destination $appDest -Recurse -Force
            Write-Host "  [OK] Deployed AutomatedLab Studio app to $appDest" -ForegroundColor Green
        }
    }
}

# Register the REST endpoints used by the AUTOMATElab landing dashboard.
$endpointScript = Join-Path $PSScriptRoot "scripts\07_Register_WebFrontend_Endpoints.ps1"
if (Test-Path $endpointScript) {
    & $endpointScript
}

Restart-Service -Name "PowerShellUniversal" -ErrorAction SilentlyContinue
Write-Host "  [OK] Web frontend ready." -ForegroundColor Green

# 9. Final report
Write-Host "`n====================================================================" -ForegroundColor Green
Write-Host " PLATFORM BOOTSTRAP COMPLETE" -ForegroundColor Green
Write-Host " Web Control Portal:       http://localhost:5000" -ForegroundColor Cyan
Write-Host " AutomatedLab Studio:      http://localhost:5000/automatedlab" -ForegroundColor Cyan
Write-Host " Apache Guacamole Gateway: http://localhost:8443/guacamole (change default guacadmin/guacadmin!)" -ForegroundColor Cyan
Write-Host " Storage Root ($storageFs): $StorageRoot" -ForegroundColor Cyan
Write-Host " LabSources Repository:    $LabSourcesRoot" -ForegroundColor Cyan
if ($rebootRequired) {
    Write-Host "" -ForegroundColor Yellow
    Write-Host " *** A REBOOT IS REQUIRED to finish enabling Hyper-V. ***" -ForegroundColor Yellow
    Write-Host " *** Re-run this script after rebooting to complete VM path setup and Guacamole. ***" -ForegroundColor Yellow
}
Write-Host "====================================================================" -ForegroundColor Green
