# AutomatedLab Platform — Environment Install Runbook

This runbook installs **PowerShell 7** and **every prerequisite** needed to build and run the
AutomatedLab Platform on a clean host. The setup scripts are idempotent — they are safe to re-run.

> Target environment: **Windows Server 2022 / 2025** (or **Windows 11 Pro / Enterprise** for development).
> All commands require an **elevated (Run as Administrator)** PowerShell prompt.

---

## 1. What gets installed

| Component | Purpose | Installer |
| :--- | :--- | :--- |
| **PowerShell 7 (7.4+)** | Runtime for PowerShell Universal 5.x background workers | `setup/Install-PowerShell7.ps1` |
| **NuGet + PowerShellGet + PSResourceGet** | Module/package providers | `setup/Install-Prerequisites.ps1` |
| **Git** | Source control for lab repos | winget (auto-installed if missing) |
| **Python 3.12 + pip** | Docker Compose generator + Keeper CLI | winget → python.org fallback |
| **Docker** | Guacamole gateway + Phase 2 containers | Docker Engine (Server) / Docker Desktop (Win11) |
| **WSL 2** | Docker Desktop's Linux container backend (client OS) | `setup/Install-Prerequisites.ps1` |
| **Keeper Commander** | Headless secret import (`keeper import`) | pip |
| **AutomatedLab + Common/Core/Definition/Worker** | Hyper-V lab automation engine | `Fast-Setup.ps1` |
| **PowerShell Universal (PSU)** | Web control plane + service | `Fast-Setup.ps1` |
| **Hyper-V, PSRemoting, fast storage** | Hypervisor + storage (ReFS 64KB; NTFS fallback on Win11 Pro) | `Fast-Setup.ps1` |
| **Apache Guacamole** | HTML5 RDP/SSH gateway (Docker Compose) | `Fast-Setup.ps1` |
| **Web Frontend (AutomatedLab Studio)** | Web GUI for lab/ISO/role management at `/automatedlab` | `Fast-Setup.ps1` (PowerShellUniversal.Apps.AutomatedLab) |

---

## 2. Prerequisites

- **OS:** Windows Server 2022 / 2025, or Windows 11 Pro / Enterprise.
- **Account:** Local Administrator (or equivalent) for the entire run.
- **Hardware:** A second physical/NVMe disk for fast storage (or `-SkipDiskFormat`). ReFS 64KB
  block cloning is used on Server / Pro for Workstations; Windows 11 Pro falls back to NTFS automatically.
- **Network:** Outbound HTTPS (PSGallery, winget, GitHub, python.org, Docker Hub).

---

## 3. Quick start (single command)

Copy the platform to the host (e.g. `C:\AutomatedLabSuite`), then in an **elevated** PowerShell:

```powershell
Set-Location C:\AutomatedLabSuite
.\setup\Build-Platform.ps1
```

Defaults: formats **Disk 1** on **V:** (ReFS 64KB where supported; NTFS fallback on Windows 11 Pro),
enables Hyper-V, installs all modules + PowerShell Universal, and deploys Guacamole on
`http://localhost:8443`.

Common variants:

```powershell
# Use a different disk / drive letter, skip disk formatting (existing volume)
.\setup\Build-Platform.ps1 -TargetDiskNumber 2 -StorageDriveLetter S -SkipDiskFormat

# Fully automatic: reboot and resume without further input
.\setup\Build-Platform.ps1 -AutoReboot

# Toolchain already installed — skip it and only run the platform setup
.\setup\Build-Platform.ps1 -SkipPrerequisites -SkipPowerShell7

# Skip Docker/Keeper tooling entirely
.\setup\Build-Platform.ps1 -SkipKeeperCommander
```

> **Reboot note:** enabling Hyper-V, WSL2, the Containers feature, or Docker Engine requires a
> reboot. `Build-Platform.ps1` registers an elevated one-time scheduled task, so the setup
> **resumes automatically** after you reboot and log back in — no manual re-run needed.
> Add `-AutoReboot` to restart the host automatically.

---

## 4. Step-by-step (manual / granular)

If you prefer to run phases individually:

```powershell
# 1. Toolchain (NuGet, PowerShellGet, Git, Python, Docker, Keeper CLI)
.\setup\Install-Prerequisites.ps1

# 2. PowerShell 7 runtime
.\setup\Install-PowerShell7.ps1

# 3. Platform (Hyper-V, ReFS, AutomatedLab modules, PSU, Guacamole)
.\Fast-Setup.ps1 -TargetDiskNumber 1 -StorageDriveLetter V
```

---

## 5. Verify the installation

```powershell
pwsh -NoProfile -Command '$PSVersionTable.PSVersion'   # 7.4 or higher
docker --version                                       # Docker CLI present
docker compose version                                 # Compose v2 plugin present
python --version                                       # 3.12
keeper version                                         # Keeper Commander CLI
Get-Module -ListAvailable AutomatedLab, PowerShellUniversal | Select Name, Version
Get-Service PowerShellUniversal                        # Running
Get-VMHost                                             # Hyper-V paths point at V:\Hyper-V
```

Final build-time verification is also printed automatically by `Build-Platform.ps1` (Phase 4).

---

## 6. Troubleshooting

- **`winget` is not recognized.** The scripts auto-install App Installer. If that fails, install
  winget manually or rely on the built-in fallbacks (python.org installer, Microsoft's Docker CE
  script).
- **`docker` missing after Docker Engine install.** Reboot the host, then re-run
  `.\setup\Install-Prerequisites.ps1`. On Windows Server the Docker Engine runs **Windows**
  containers by default.
- **Guacamole stack won't start.** The Guacamole images (`guacamole/guacamole`, `guacd`,
  `postgres:15-alpine`) are **Linux** containers. `Fast-Setup.ps1` now detects the Docker
  container OS and skips Guacamole (with guidance) when only Windows containers are available.
  Run the `configs/docker-compose.guacamole.yml` stack on Docker Desktop with the WSL2 backend
  (Windows 11) or on a Linux guest VM — see the Architecture Guide's "Container Hosts" section.
- **ReFS block cloning not available.** `Fast-Setup.ps1` falls back to NTFS automatically on
  editions that can't create ReFS (e.g. Windows 11 Pro). Confirm with
  `Get-Volume -DriveLetter V | Format-List FileSystem, AllocationUnitSize`. Use Windows Server or
  Windows 11 Pro for Workstations for ReFS block cloning.
- **PowerShell Universal service not registered.** Run an elevated `pwsh`, then
  `Install-PSUServer -InstallDirectory "C:\Program Files\PowerShell Universal" -Service`.

---

## 7. Related documentation

- `README.md` — orientation & quickstart
- `docs/Architecture-and-Operations-Guide.md` — full platform specification
- `docs/Keeper-Integration-Guide.md` — secret import runbook & CLI automation
