# AutomatedLab Web Frontend & No-Code Orchestrator Specification

**Document Version:** 1.0.0  
**Status:** Approved Architecture Draft  
**Target Architecture:** React 18 / Vite, Tailwind CSS, React Flow, PowerShell Universal 5.x, AutomatedLab 5.x  
**Audience:** Platform Engineers, Frontend Developers, Cloud & Lab Architects  

---

## 1. Executive Summary & Product Vision

The **AutomatedLab No-Code Web Studio** transforms complex, multi-tiered infrastructure scripting into an intuitive, visual, drag-and-drop canvas. It bridges the gap between infrastructure architects and non-scripting consumers (QA engineers, security analysts, sales engineers, and developers) by allowing users to visually assemble, configure, deploy, access, and decommission complete virtualized environments without writing a single line of PowerShell or YAML.

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                   No-Code Visual Web Studio                                      │
│  ┌───────────────────────────┐ ┌──────────────────────────────────┐ ┌──────────────────────────┐ │
│  │   Palette / Node Drawer   │ │        Visual Graph Canvas       │ │   Properties Inspector   │ │
│  │  • Windows Server Roles   │ │   [DC01] ─── (Domain Join) ────┐ │ │  • RAM: 4096 MB Dynamic   │ │
│  │  • Linux / Docker Nodes   │ │     │                          ▼ │ │  • vCPU: 2 Cores          │ │
│  │  • Custom Artifacts (.msi)│ │  (NAT vSwitch) ─────────> [WEB01]│ │  • Domain: corp.internal  │ │
│  │  • Container Services     │ │     │                            │ │  • IP: 192.168.50.20      │ │
│  │  • Isolated Subnets       │ │     ▼                            │ │  • Base Disk: Win2022.iso │ │
│  │                           │ │ [DOCKER-NODE01] (Postgres+Redis) │ │  • Checkpoint: Enabled    │ │
│  └───────────────────────────┘ └──────────────────────────────────┘ └──────────────────────────┘ │
└─────────────────────────────────┬──────────────────────────────────┬─────────────────────────────┘
                                  │ Bidirectional JSON Graph State   │ WebSocket Telemetry
┌─────────────────────────────────▼──────────────────────────────────▼─────────────────────────────┐
│                           Platform Translation & Execution Engine                                │
│   • Graph-to-Code Compiler: Transforms Node-Graph ──> AutomatedLab `LabDefinition.ps1`           │
│   • Container Stack Synthesizer: Generates `docker-compose.yml` + Cryptographic `.env`          │
│   • Secret Escrow Engine: Emits Schema-Compliant `keeper_secrets_export.json`                    │
│   • Guacamole Console Injector: Dynamically Maps HTML5 Browser Sessions (RDP/SSH)                │
└─────────────────────────────────┬────────────────────────────────────────────────────────────────┘
                                  │ PowerShell Direct / VMBus / WinRM / Hyper-V WMI
┌─────────────────────────────────▼────────────────────────────────────────────────────────────────┐
│                             Hyper-V Hypervisor on ReFS (64KB Clones)                             │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. System Architecture & Tech Stack

| Tier | Component | Technology Selection | Rationale |
| :--- | :--- | :--- | :--- |
| **Frontend Framework** | Single-Page Application (SPA) | **React 18 + Vite (TypeScript)** | Sub-second HMR development, typed component contracts, and high performance. |
| **Visual Node Engine** | Drag-and-Drop Graph Canvas | **React Flow (`@xyflow/react`)** | Production-ready node/edge canvas, port snapping, customizable SVG rendering, and zoom/pan. |
| **Styling & Components** | UI Component System | **Tailwind CSS + shadcn/ui** | Accessible, headless primitives (Radix UI), dark-mode native, and low bundle footprint. |
| **State Management** | Global Client State | **Zustand + Immer** | Immutable graph mutation, undo/redo history stack, and lightweight store persistence. |
| **Host Control Plane** | Backend API & Worker Engine | **PowerShell Universal (PSU) 5.x** | Native PowerShell 7.4+ execution, gMSA service context, and built-in WebSocket streaming. |
| **Console Access** | In-Browser HTML5 Gateway | **Apache Guacamole (Docker)** | Zero-client RDP/SSH canvas rendering over WebSocket tunnel without opening host ports. |
| **Secret Management** | Credentials & Key Escrow | **Keeper Security (JSON / CLI)** | Automated password entropy, custom fields mapping, and vault import compatibility. |

---

## 3. UI Layout & Core Functional Modules

The application layout is structured around an IDE-grade three-pane workbench:

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [Logo] AutomatedLab Studio | Active Lab: "SecOps-Sandbox" | [RAM: 42GB Free] [vCPU: 1.2x] [Deploy] │
├──────────────┬────────────────────────────────────────────────────────────┬───────────────────────┤
│ NODE PALETTE │                     VISUAL FLOW CANVAS                     │ PROPERTY INSPECTOR    │
│              │                                                            │                       │
│ ▾ Compute    │   ┌──────────────┐         ┌──────────────┐                │ Selected: DC01        │
│   [WinServer]│   │ DC01 (AD/DNS)│         │ WEB01 (IIS)  │                │ Operating System:     │
│   [Win 11]   │   │ 192.168.50.10│         │ 192.168.50.20│                │ [ Windows Server 2022]│
│   [Ubuntu]   │   └──────┬───────┘         └──────┬───────┘                │                       │
│              │          │ (Domain Member)        │                        │ RAM Allocation (MB):  │
│ ▾ Network    │          └────────────────────────┤                        │ [===|======] 4096 MB  │
│   [vSwitch]  │                                   │                        │ Dynamic Memory: [x]   │
│   [Gateway]  │                        ┌──────────┴──────────┐             │                       │
│              │                        │ LabSwitch (vSwitch) │             │ vCPU Core Count:      │
│ ▾ Containers │                        │ 192.168.50.0/24     │             │ [ 2 Cores           ] │
│   [Postgres] │                        └──────────┬──────────┘             │                       │
│   [Redis]    │                                   │                        │ Roles Assigned:       │
│   [NGINX]    │                        ┌──────────┴──────────┐             │ [*] RootDC  [*] DNS   │
│              │                        │ DOCKER-HOST-01      │             │                       │
│ ▾ Custom Apps│                        │ Postgres 16 + Redis │             │ Assigned IP Address:  │
│   [App Upload]                        └─────────────────────┘             │ [ 192.168.50.10     ] │
├──────────────┴────────────────────────────────────────────────────────────┴───────────────────────┤
│ ▾ LIVE TELEMETRY & TERMINAL: [Deploying DC01: Hydrating base disk via ReFS Block Clone... 100%]    │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.1 Module 1: The Palette Drawer (Left Sidebar)
Provides a searchable, categorized library of drag-and-drop primitives:
* **Compute Primitives:** Pre-configured OS images detected from `V:\LabSources\ISOs` (Windows Server 2022/2025 Datacenter, Windows 11 Enterprise, Ubuntu 24.04 LTS).
* **Role Primitives:** AutomatedLab native roles (Active Directory Root DC, Child DC, DNS, DHCP, Web Server IIS, SQL Server, Routing Gateway).
* **Container Services:** Microservice containers (PostgreSQL 16, Redis 7.2, NGINX, RabbitMQ, Kafka).
* **Custom Artifacts:** Proprietary `.msi`, `.exe`, or `.ps1` installers uploaded via the application delivery portal.
* **Network Primitives:** Virtual switches, NAT gateways, internal private boundaries, and external adapters.

### 3.2 Module 2: Visual Canvas (Center Pane)
* **Auto-Wiring & Snapping:** Connecting a virtual machine node to a virtual switch automatically assigns the next available sequential IP from that switch's address pool.
* **Smart Relationship Validation:** Dragging an edge from a `WebServer` node to a `RootDC` node prompts the user: *"Join this machine to domain 'corp.internal'?"* and automatically configures domain credentials and DNS forwarding.
* **Live Status Overlay:** Running labs display real-time machine states (Running, Stopped, Provisioning, Error) with pulsating color-coded border indicators.
* **1-Click Web Console Access:** Clicking a node's terminal icon opens the embedded Apache Guacamole HTML5 console inside a floating modal or new tab.

### 3.3 Module 3: Property Inspector (Right Sidebar)
Displays contextual properties for the currently selected node:
* **Hardware Sizing:** Sliders for dynamic RAM minimum/maximum thresholds and vCPU core allocations.
* **Network Configuration:** Subnet selector, manual or DHCP IP assignment, VLAN ID tags.
* **Software Provisioning:** Checkboxes for Chocolatey packages, custom script injection, and post-installation verification tests.
* **Container Environment Variables:** Key-value pairs with an **Auto-Generate Secure Token** button that injects 256-bit entropy values.

### 3.4 Module 4: Bottom Drawer (Telemetry, Console & Logs)
* **WebSocket Log Stream:** Displays colored, formatted live deployment transcripts from `Install-Lab`.
* **Resource Overcommit Gauges:** Continuously updates host physical RAM utilization and prevents builds if requested resources exceed available capacity.
* **Artifact Download Bar:** Generates downloadable buttons for `LabDefinition.ps1`, `docker-compose.yml`, `.env`, and `keeper_secrets_export.json`.

---

## 4. No-Code Canvas Graph Schema Specification

The entire visual topology is serialized as an immutable JSON document conforming to the following schema:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "AutomatedLabVisualTopology",
  "type": "object",
  "required": ["labName", "addressSpace", "nodes", "edges"],
  "properties": {
    "labName": { "type": "string" },
    "addressSpace": { "type": "string", "pattern": "^\\d{1,3}(\\.\\d{1,3}){3}/\\d{1,2}$" },
    "gatewayIp": { "type": "string" },
    "nodes": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["id", "type", "data"],
        "properties": {
          "id": { "type": "string" },
          "type": { "enum": ["vmNode", "vSwitchNode", "containerNode", "customAppNode"] },
          "data": {
            "type": "object",
            "properties": {
              "label": { "type": "string" },
              "os": { "type": "string" },
              "ramMb": { "type": "integer", "minimum": 1024 },
              "vCpu": { "type": "integer", "minimum": 1 },
              "ipAddress": { "type": "string" },
              "roles": { "type": "array", "items": { "type": "string" } },
              "domainName": { "type": "string" },
              "customPackages": { "type": "array", "items": { "type": "string" } },
              "containerConfig": {
                "type": "object",
                "properties": {
                  "services": { "type": "array", "items": { "type": "string" } },
                  "generateSecrets": { "type": "boolean" },
                  "exportKeeper": { "type": "boolean" }
                }
              }
            }
          }
        }
      }
    },
    "edges": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["id", "source", "target", "relationType"],
        "properties": {
          "id": { "type": "string" },
          "source": { "type": "string" },
          "target": { "type": "string" },
          "relationType": { "enum": ["connectsToSwitch", "domainJoin", "dependsOn"] }
        }
      }
    }
  }
}
```

---

## 5. Bidirectional Code & Graph Compiler

The engine maintains complete parity between the visual graph and the generated code.

### 5.1 Graph-to-Code Pipeline
When the user clicks **Deploy** or **Export Script**, the compiler executes three sequential passes:
1. **Pass 1 (Network Sizing):** Traverses `vSwitchNode` items to declare virtual networks (`Add-LabVirtualNetworkDefinition`).
2. **Pass 2 (Machine & Role Declaration):** Analyzes `vmNode` elements, evaluates incoming `domainJoin` edges, and writes `Add-LabMachineDefinition` blocks.
3. **Pass 3 (Container & Secret Generation):** For nodes with container configurations, calls `docker_compose_keeper_generator.py` to write `docker-compose.yml`, `.env`, and `keeper_secrets_export.json`.

```typescript
// Sample TypeScript Compiler Function
export function compileGraphToPowerShell(graph: VisualTopology): string {
  let ps = `# Autogenerated by AutomatedLab No-Code Studio\n`;
  ps += `Import-Module AutomatedLab -Force\n\n`;
  ps += `New-LabDefinition -Name '${graph.labName}' -DefaultVirtualMachineAdministratorCredential (Get-Credential)\n`;
  
  // 1. Networks
  const switches = graph.nodes.filter(n => n.type === 'vSwitchNode');
  switches.forEach(sw => {
    ps += `Add-LabVirtualNetworkDefinition -Name '${sw.data.label}' -AddressSpace '${sw.data.addressSpace}'\n`;
  });

  // 2. Machines
  const vms = graph.nodes.filter(n => n.type === 'vmNode');
  vms.forEach(vm => {
    const roles = vm.data.roles && vm.data.roles.length > 0 
      ? ` -Roles @(${vm.data.roles.map(r => `'${r}'`).join(', ')})` 
      : '';
    const domain = vm.data.domainName ? ` -DomainName '${vm.data.domainName}'` : '';
    ps += `Add-LabMachineDefinition -Name '${vm.data.label}' -OperatingSystem '${vm.data.os}' ` +
          `-Memory ${vm.data.ramMb}MB -vCPU ${vm.data.vCpu} -Network '${switches[0].data.label}' ` +
          `-IpAddress '${vm.data.ipAddress}'${domain}${roles}\n`;
  });

  ps += `\nInstall-Lab -UseBaseDisks -Verbose\n`;
  return ps;
}
```

---

## 6. AI Copilot Integration (Bidirectional Sync)

The No-Code Studio integrates an **AI Chat Drawer** powered by the AI LabOps Architect Agent:

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────┐
│ AI ARCHITECT COPILOT                                                                             │
│                                                                                                  │
│ User: "Add an Ubuntu container host running Postgres and Redis, and wire it to LabSwitch."       │
│                                                                                                  │
│ Agent: "I have added DOCKER-NODE01 (Ubuntu 24.04, 8GB RAM, IP 192.168.50.50), generated         │
│         hardened docker-compose.yml with cryptographic credentials, and wired it to LabSwitch.   │
│         The canvas has been updated. Estimated host RAM impact: +8 GB."                          │
│                                                                                                  │
│ [Accept Changes & Redraw Canvas]   [Review Diff]   [Discard]                                     │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘
```

* **Text-to-Canvas:** Prompts parsed by the AI Agent emit updated JSON topology states that trigger React Flow's layout engine to smoothly animate new nodes into place.
* **Canvas-to-Text Context:** When the user asks *"Why is DC01 using 4 GB RAM?"*, the agent reads the current graph selection and explains the sizing constraints based on the Active Directory role.

---

## 7. Security, Access Governance & Keeper Integration

* **Role-Based Access Control (RBAC):**
  * *Lab Consumers:* Permitted only to instantiate pre-approved templates and access personal HTML5 consoles.
  * *Lab Architects:* Full access to drag-and-drop canvas, custom app uploading, and container composition.
  * *Administrators:* Storage volume formatting, quota ceiling overrides, and global lease auditing.
* **Zero-Cleartext Secret Export:** Passwords generated for database services, local administrative accounts, and container tokens are never rendered in plain text on the web canvas. Operators click **Export to Keeper** to download the encrypted payload (`keeper_secrets_export.json`) directly for import into Keeper Desktop Vault or automated consumption via Keeper Commander CLI.

---

## 8. Frontend Engineering Delivery Milestones

| Milestone | Deliverable Scope | Acceptance Criteria |
| :--- | :--- | :--- |
| **M1: Core Canvas Scaffolding** | React Flow integration, custom node components (`vmNode`, `switchNode`, `containerNode`), pan/zoom. | Visual canvas renders nodes; ports allow dragging connection edges with collision rejection. |
| **M2: Inspector & Property Sheets** | Contextual property drawer, dynamic RAM/CPU sliders, role multiselect, subnet validation. | Selecting a node updates the inspector; modifications update Zustand store and trigger edge validation. |
| **M3: Graph Compiler & PSU Integration** | Bidirectional graph-to-PowerShell compiler, REST API bindings to `/api/v1/labs/deploy`. | Canvas state compiles to valid `LabDefinition.ps1`; clicking Deploy triggers background PSU job. |
| **M4: Live Telemetry & Console Modal** | WebSocket log streaming, live status badges, Guacamole iframe modal integration. | Real-time deployment logs stream to bottom drawer; clicking "Console" opens active HTML5 RDP/SSH desktop. |
| **M5: AI Copilot Sync & Keeper Export** | Chat drawer integration, text-to-canvas rendering, 1-click Keeper export generation. | Conversational prompts update canvas visually; Keeper JSON downloads and passes official CLI schema checks. |
