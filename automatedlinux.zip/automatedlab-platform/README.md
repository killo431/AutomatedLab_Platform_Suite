# AutomatedLab Platform Enterprise Suite

A complete Lab-as-a-Service (LaaS) automation platform pairing Hyper-V, ReFS 64KB block cloning, PowerShell Universal, Apache Guacamole HTML5 console access, and Phase 2 Docker Compose with Keeper Security integration.

## Folder Structure
```
automatedlab-platform/
├── README.md                           # Master orientation and quickstart guide
├── INSTALL.md                          # Bare-metal install runbook (PowerShell 7 + deps)
├── requirements.txt                    # Python tooling (Keeper Commander CLI)
├── Fast-Setup.ps1                      # Turnkey, automated host bootstrap script
├── setup/
│   ├── Build-Platform.ps1              # Master orchestrator: prerequisites + platform
│   ├── Install-PowerShell7.ps1         # PowerShell 7.4+ installer
│   └── Install-Prerequisites.ps1       # NuGet, Git, Python, Docker, Keeper CLI
├── docker/
│   ├── docker-compose.yml              # Containerized control plane (PSU + Guacamole)
│   ├── .env.example                    # Secret template for the container stack
│   ├── Caddyfile                       # Reverse proxy / TLS config
│   └── README.md                       # Docker Compose deployment runbook
├── docs/
│   ├── Architecture-and-Operations-Guide.md  # Comprehensive platform specification
│   └── Keeper-Integration-Guide.md           # Secret import runbook & CLI automation
├── scripts/
│   ├── 01_Configure_ReFS_Storage.ps1         # ReFS 64KB cluster volume formatter
│   ├── 02_Register_Guacamole_Connection.ps1   # REST connection injector for Guacamole
│   ├── 03_Custom_Service_App_Delivery.ps1    # Multipart upload & guest installer
│   ├── 04_Docker_Compose_Keeper_Generator.py # 1-Click Compose & Keeper JSON generator
│   └── 05_Invoke_Lab_Reaper.ps1              # Scheduled TTL lease cleanup engine
├── configs/
│   ├── docker-compose.guacamole.yml          # Container stack for HTML5 web console
│   ├── app-manifest.template.json            # Custom software package descriptor
│   └── caddy.conf                            # Reverse proxy TLS termination config
└── templates/
    ├── sample_keeper_secrets_export.json     # Validated Keeper Commander import schema
    ├── docker-compose.template.yml           # Base container stack manifest
    └── env.template                          # Environment variable template
```

## Quick Start
1. Unzip this package to your Windows Server (or Windows 11 Pro) host: `C:\AutomatedLabSuite`.
2. Open PowerShell as Administrator.
3. Run the full environment build (installs PowerShell 7 + all prerequisites, then the platform):
   ```powershell
   .\setup\Build-Platform.ps1 -TargetDiskNumber 1 -StorageDriveLetter V
   ```
   The build registers an elevated resume task and **continues automatically** after any required
   reboot (Hyper-V, WSL2, Docker). Pass `-AutoReboot` to restart the host automatically.
   Or run just the platform bootstrap (assumes prerequisites are already installed):
   ```powershell
   .\Fast-Setup.ps1 -TargetDiskNumber 1 -StorageDriveLetter V
   ```
4. Access the web dashboard at `http://localhost:5000` and Guacamole at `http://localhost:8443`.

> **Windows 11 Pro note:** ReFS creation isn't available on Windows 11 Pro, so the storage step
> automatically falls back to NTFS. ReFS 64KB block cloning requires Windows Server or Pro for Workstations.

See **[INSTALL.md](INSTALL.md)** for the full dependency list, granular install steps,
verification commands, and troubleshooting.

## Docker Compose Deployment (containerized control plane)
Prefer containers over a bare-metal install? The `docker/` directory deploys the
PowerShell Universal control plane, Apache Guacamole console gateway, and Caddy reverse
proxy as Linux containers:

```bash
cd docker
cp .env.example .env      # then edit the passwords
docker compose up -d
```

One-command automatic Linux setup: `cd linux && sudo ./setup.sh` (installs Docker + Compose +
Python, then deploys). See **[linux/README.md](linux/README.md)**.

Web frontends: AUTOMATElab dashboard at `http://localhost/`, AutomatedLab Studio at
`http://localhost/automatedlab`, Guacamole at `http://localhost/guacamole`.
See **[docker/README.md](docker/README.md)** for details. Note that the Hyper-V/AutomatedLab
lab engine still runs on a Windows Server or Windows 11 Pro host.

## Web Frontend (React/Vite No-Code Canvas)
The `web/` directory is the React 18 + Vite + React Flow + Tailwind no-code canvas (spec **M1**):
drag-and-drop palette, React Flow canvas, custom VM/switch/container nodes, and Zustand state.

```bash
cd web
npm install
npm run dev     # http://localhost:5173 (proxies /api to PSU :5000)
```

`Fast-Setup.ps1` now also installs the **AutomatedLab MSI** (full installer with worker binaries) and
the community **AutomatedLab Studio** app at `/automatedlab`. See **[web/README.md](web/README.md)**.
