# AutomatedLab Platform — Docker Compose Deployment

A containerized alternative to the bare-metal Windows install. This stack runs the
**browser-facing control plane and HTML5 console gateway** as Linux containers:

| Service | Image | Role | Host port |
| :--- | :--- | :--- | :--- |
| `psu` | `devolutions/powershell-universal:latest` | Web control plane (dashboards, APIs, jobs) | `5000` |
| `psu-db` | `postgres:16-alpine` | PowerShell Universal database | — |
| `guacd` | `guacamole/guacd:latest` | Guacamole proxy daemon | — |
| `guacamole` | `guacamole/guacamole:latest` | HTML5 RDP/SSH console web app | `8443` → `8080` |
| `guac-db` | `postgres:15-alpine` | Guacamole database (schema auto-initialized) | — |
| `caddy` | `caddy:2-alpine` | Reverse proxy / TLS termination | `80`, `443` |
| `status` | `python:3.12-alpine` | AUTOMATElab dashboard status/labs API | — |

> **Important:** PowerShell Universal and Guacamole are containerized here, but the
> **Hyper-V / AutomatedLab lab-provisioning engine must still run on a Windows Server host**
> (AutomatedLab requires the Hyper-V Windows modules). Use this stack as the web front-end
> that reaches that host remotely, or run the bare-metal `setup/Build-Platform.ps1` for an
> all-in-one Windows install.

---

## 1. Prerequisites

- **Docker Engine** (Linux) or **Docker Desktop** (Windows/macOS) in **Linux containers** mode.
- **Docker Compose v2** (`docker compose version`).
- At least **2 GB** memory available to Docker.
- Free host ports `5000`, `8443`, `80`, `443` (adjustable in `docker-compose.yml`).

---

## 2. Quick start

```bash
cd automatedlab-platform/docker

# 1. Create your secret values (edit the file first)
cp .env.example .env

# 2. Pull images
docker compose pull

# 3. Start the stack (first run initializes the Guacamole schema automatically)
docker compose up -d

# 4. Watch startup
docker compose logs -f psu guacamole
```

Wait ~30 s, then open:

- **PowerShell Universal:** http://localhost:5000 (complete the first-time setup wizard)
- **Guacamole console:** http://localhost:8443/guacamole (default: `guacadmin` / `guacadmin` — change immediately)
- **Via Caddy:** http://localhost (PSU) and http://localhost/guacamole (Guacamole)

---

## 3. Configuration

- **Secrets** live in `.env` (`PSU_DB_PASSWORD`, `GUACAMOLE_DB_PASSWORD`). Do not commit it.
  Avoid `$` and `;` in these values (Compose interpolation + the PSU connection string).
- **Routing / TLS** is in `Caddyfile`. The `:80` block serves HTTP; uncomment the domain
  block and set `PLATFORM_HOSTNAME` for automatic HTTPS.
- **Ports** are the left-hand values in each `ports:` entry — change them to avoid conflicts.

---

## 4. Opt-in profiles (generator & app stack)

### Generator (`--profile generator`)
The `generator` service is a one-shot `python:3.12-alpine` container that runs the 1-Click
Docker Compose + Keeper generator (`../scripts/04_Docker_Compose_Keeper_Generator.py`). It writes
`docker-compose.yml`, `.env`, `nginx.conf`, and `keeper_secrets_export.json` into `./generated/`:

```bash
docker compose --profile generator run --rm generator

# customize project name / target host:
docker compose --profile generator run --rm \
  -e PROJECT_NAME=BillingMicroservices \
  -e TARGET_HOST_IP=192.168.10.50 \
  generator

ls -la generated/
```

### Phase 2 app stack (`--profile apps`)
Opt-in Postgres + Redis + nginx stack (mirrors `templates/docker-compose.template.yml`):

```bash
docker compose --profile apps up -d
```

- `app-postgres` — `localhost:5433` (user/db/password from `.env` `APP_POSTGRES_*`)
- `app-redis` — `localhost:6379` (password from `.env` `APP_REDIS_PASSWORD`)
- `app-nginx` — `http://localhost:8080` (HTTP) / `https://localhost:8444` (HTTPS placeholder)

Host ports are remapped (`8080`, `8444`, `5433`) to avoid clashing with Caddy and Guacamole.

---

## 5. Common operations

```bash
docker compose ps                 # status
docker compose logs -f psu        # follow PSU logs
docker compose restart psu        # restart the control plane
docker compose down               # stop + remove containers (keeps volumes)
docker compose down -v            # ALSO delete all data (DBs, PSU repo) — destructive
```

---

## 6. How the Guacamole database is initialized

The `guac-db-init` one-shot service runs the image's
`/opt/guacamole/bin/initdb.sh --postgresql` and writes `guacamole/init/initdb.sql` to a
bind mount. `guac-db` mounts that file at `/docker-entrypoint-initdb.d/`, so PostgreSQL
creates the schema on first boot. `depends_on: condition: service_completed_successfully`
guarantees the schema exists before the database starts.

To force a clean re-init (e.g. after an image/schema change):

```bash
docker compose down -v guac-db
rm -f guacamole/init/initdb.sql
docker compose up -d
```

---

## 7. Troubleshooting

- **`password authentication failed for user "psu"`** — PostgreSQL only applies
  `POSTGRES_PASSWORD` the first time the `psu-db-data` volume is created. Recreate the
  volume (`docker compose down -v psu-db`) or revert to the original password.
- **PSU can't reach PostgreSQL** — confirm the `depends_on` healthcheck is present and
  `docker compose logs psu-db` shows `accepting connections`.
- **Guacamole login fails / blank console** — verify `guacamole/init/initdb.sql` exists and
  was mounted (`docker compose exec guac-db ls /docker-entrypoint-initdb.d`).
- **Port already in use** — change the host port in `ports:` (e.g. `"8080:5000"`).
- **No lab provisioning** — this stack does not run AutomatedLab/Hyper-V. Configure PSU to
  reach your Windows Server host via WinRM/SSH, or install the Windows platform.

---

## 8. Related documentation

- `../INSTALL.md` — bare-metal Windows Server install runbook
- `../docs/Architecture-and-Operations-Guide.md` — full platform specification
- `../docs/Keeper-Integration-Guide.md` — secret import runbook
