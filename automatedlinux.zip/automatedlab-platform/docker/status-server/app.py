#!/usr/bin/env python3
"""Lightweight status API for the AutomatedLab Platform Linux control plane.

Serves the AUTOMATElab dashboard's endpoints so the landing page shows live
status when the platform runs as a Linux container stack (where AutomatedLab /
Hyper-V are not present).

Endpoints:
  GET /api/v1/automatelab/status
  GET /api/v1/automatelab/labs
"""
import json
import os
import socket
from http.server import BaseHTTPRequestHandler, HTTPServer

PORT = int(os.environ.get("PORT", "8080"))
LAB_REGISTRY = os.environ.get("LAB_REGISTRY", "/data/LabRegistry.json")


def read_labs():
    if not os.path.exists(LAB_REGISTRY):
        return []
    try:
        with open(LAB_REGISTRY, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else [data]
    except Exception:
        return []


class Handler(BaseHTTPRequestHandler):
    def _json(self, payload):
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/api/v1/automatelab/status"):
            self._json({
                "host": os.environ.get("HOSTNAME", socket.gethostname()),
                "mode": "linux-control-plane",
                "hyperv": False,
                "docker": True,
                "guacamole": "http://localhost/guacamole",
                "studio": None,
            })
        elif self.path.startswith("/api/v1/automatelab/labs"):
            self._json(read_labs())
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
