# AutomatedLab Platform: End-to-End Architecture, ReFS Storage Optimization, Guacamole Gateway & Phase 2 Container Ecosystem

**Document Version:** 2.4.0  
**Target Environment:** Windows Server 2022 / 2025, PowerShell Universal 5.x, AutomatedLab 5.x, Hyper-V, Docker Engine  
**Security Classification:** Internal Engineering Standard  

> **Implementation note:** the inline code samples below are illustrative. The canonical,
> up-to-date implementations live in `scripts/`, `configs/`, `setup/`, and `templates/` at the
> repository root — e.g. the Compose/Keeper generator is Python
> (`scripts/04_Docker_Compose_Keeper_Generator.py`), and the storage formatter
> (`scripts/01_Configure_ReFS_Storage.ps1`) now falls back to NTFS on editions that cannot create
> ReFS (e.g. Windows 11 Pro).

---

## 1. System Architecture Overview

The AutomatedLab Platform is an enterprise-grade Lab-as-a-Service (LaaS) automation engine that bridges hypervisor-level virtualization with a modern, self-service web control plane. It delivers programmatic, rapid hydration of multi-tier Windows and Linux environments, isolated network sandboxes, custom software injection, and containerized microservice stacks.

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                   User Access Layer (Browser)                                    │
│  • HTTPS (Port 443) via Caddy/IIS Reverse Proxy             • OpenID Connect / Active Directory  │
│  • PSU Web Studio Management Dashboard                      • In-Browser HTML5 RDP/SSH Consoles  │
└─────────────────────────────────┬──────────────────────────────────┬─────────────────────────────┘
                                  │                                  │
                                  │ HTTPS / WebSocket (Port 5000)    │ Guacamole Client (Port 8443)
┌─────────────────────────────────▼──────────────────────────────────▼─────────────────────────────┐
│                             Host Control Plane & Service Mesh                                    │
│  ┌──────────────────────────────────────────────────┐ ┌────────────────────────────────────────┐ │
│  │          PowerShell Universal (PSU) Server       │ │    Apache Guacamole Gateway (Docker)   │ │
│  │  • gMSA Service Account Context                  │ │  • Guacamole Web Client (Java/Tomcat) │ │
│  │  • App Management & REST Endpoints               │ │  • Guacd Proxy Daemon (C/libguac)     │ │
│  │  • Background Worker Pool (PS 7.4+)              │ │  • Dynamic Connection REST Injector    │ │
│  │  • Template Catalog & Custom App Uploader        │ │  • Token-Based Embedded iFrame Auth    │ │
│  └──────────────────────────────┬───────────────────┘ └───────────────────┬────────────────────┘ │
│                                 │ Internal PS Engine                      │                      │
│  ┌──────────────────────────────▼─────────────────────────────────────────▼──────────────────┐   │
│  │                         AutomatedLab Core & Automation Pipelines                          │   │
│  │  • AutomatedLab Engine (Core, Common, Definition, Worker)                                 │   │
│  │  • Tiered LabSources Repository (ISOs, Tools, SoftwarePackages)                           │   │
│  │  • Phase 2 Docker Compose & Cryptographic Secret Generator                                │   │
│  │  • Keeper Security JSON/CSV Exporter Engine (Keeper Commander Schema)                     │   │
│  └──────────────────────────────┬────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────┼────────────────────────────────────────────────────────────────┘
                                  │ VMBus / PowerShell Direct / WinRM / Hyper-V WMI
┌─────────────────────────────────▼────────────────────────────────────────────────────────────────┐
│                           Hyper-V Virtualization & Storage Layer                                 │
│  ┌────────────────────────────────────────────────────────────────────────────────────────────┐  │
│  │                  Dedicated ReFS NVMe Storage Volume (64KB Cluster Size)                    │  │
│  │  • Read-Only Master Base Disks (Sysprepped VHDX Hydration)                                 │  │
│  │  • Instantaneous Child Differencing Disks via Metadata Block Cloning                       │  │
│  │  • Zero-I/O Checkpoint Merging & Storage Deduplication                                     │  │
│  └──────────────────────────────┬─────────────────────────────────────────────────────────────┘  │
│                                 │                                                                │
│  ┌──────────────────────────────▼─────────────────────────────────────────────────────────────┐  │
│  │                         Hyper-V Virtual Networking & Guest VMs                             │  │
│  │  • Private Isolated Switches + Internal NAT Gateway (192.168.10.0/24)                      │  │
│  │  • Active Directory Domain Controllers & Infrastructure Servers (Windows Server)           │  │
│  │  • Enterprise Endpoints & Developer Desktops (Windows 11 Enterprise)                       │  │
│  │  • Container Hosts (Ubuntu Linux Guest running Docker Engine + Compose Plugin)             │  │
│  └────────────────────────────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Phase 1: Core Platform Engineering & Storage Optimization

### 2.1 ReFS (64KB Cluster Size) Storage Engine & Block Cloning

#### Theoretical Foundation
Traditional NTFS volumes incur massive I/O penalties during lab provisioning because creating differencing disks or cloning master virtual hard disks requires physical block allocation and data duplication. 

The Resilient File System (ReFS v3.x), when formatted with an **Allocation Unit Size of 64KB**, utilizes **Block Cloning** (copy-on-write metadata allocation):
* **Instantaneous Virtual Disk Provisioning:** When AutomatedLab creates a VM disk from a cached base disk, ReFS performs a metadata operation that points to existing physical extents rather than copying gigabytes of data. A 20 GB Windows Server base disk is referenced in under 200 milliseconds.
* **Storage Deduplication:** Multiple virtual machines sharing identical base operating system layers consume physical disk blocks only for their unique runtime deltas.
* **Rapid Checkpointing:** Hyper-V checkpoint creation and consolidation occur purely at the ReFS metadata level, eliminating hypervisor freeze intervals.

#### Host Storage Configuration Script (`01_Configure_ReFS_Storage.ps1`)

```powershell
<#
.SYNOPSIS
    Configures dedicated NVMe storage with ReFS (64KB block size) for Hyper-V and AutomatedLab.
.DESCRIPTION
    Initializes target NVMe raw disk, formats as ReFS with 64KB cluster size, and sets Hyper-V roots.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [int]$DiskNumber = 1,

    [Parameter(Mandatory = $false)]
    [string]$DriveLetter = "V",

    [Parameter(Mandatory = $false)]
    [string]$VolumeLabel = "Lab_FastStorage"
)

Write-Host "[-] Initializing Disk $DiskNumber for high-performance lab operations..." -ForegroundColor Cyan

# Bring disk online and initialize GPT
Initialize-Disk -Number $DiskNumber -PartitionStyle GPT -ErrorAction SilentlyContinue
Set-Disk -Number $DiskNumber -IsOffline $false -IsReadOnly $false

# Create primary partition consuming full drive capacity
$Partition = New-Partition -DiskNumber $DiskNumber -UseMaximumSize -DriveLetter $DriveLetter

# Format with ReFS and 64KB Allocation Unit Size
Write-Host "[-] Formatting volume $DriveLetter`: with ReFS (AllocationUnitSize = 64KB)..." -ForegroundColor Cyan
Format-Volume -DriveLetter $DriveLetter `
              -FileSystem ReFS `
              -AllocationUnitSize 64KB `
              -NewFileSystemLabel $VolumeLabel `
              -Confirm:$false

# Configure Hyper-V storage defaults to ReFS root
Write-Host "[-] Configuring Hyper-V Host paths to $DriveLetter`:..." -ForegroundColor Cyan
Set-VMHost -VirtualHardDiskPath "$DriveLetter`:\Hyper-V\Virtual Hard Disks" `
           -VirtualMachinePath "$DriveLetter`:\Hyper-V\Virtual Machines"

# Structure LabSources directory on ReFS
$LabSourcesRoot = "$DriveLetter`:\LabSources"
$Directories = @(
    "$LabSourcesRoot\ISOs",
    "$LabSourcesRoot\SoftwarePackages",
    "$LabSourcesRoot\Tools",
    "$LabSourcesRoot\CustomUploads",
    "$LabSourcesRoot\DockerTemplates"
)

foreach ($Dir in $Directories) {
    if (-not (Test-Path $Dir)) {
        New-Item -Path $Dir -ItemType Directory -Force | Out-Null
        Write-Host "  [+] Created directory: $Dir" -ForegroundColor Green
    }
}

# Update AutomatedLab core configuration to use the ReFS volume
Set-LabConfiguration -LabSourcesLocation $LabSourcesRoot
Write-Host "[OK] Storage subsystem initialized with ReFS Block Cloning." -ForegroundColor Green
```

---

### 2.2 In-Browser Remote Console: Apache Guacamole HTML5 Gateway

#### Architecture & Communication Flow
To eliminate the need for exposing native RDP (Port 3389) or SSH (Port 22) to client workstations, Apache Guacamole is deployed as a containerized gateway. The flow operates as follows:
1. When AutomatedLab provisions a VM, it records the guest's internal IP address, hostname, and operating system type.
2. A PowerShell Universal background trigger calls Guacamole's REST API (`/api/tokens` and `/api/session/data/{dataSource}/connections`) to dynamically register the VM connection under an isolated user group.
3. The PowerShell Universal frontend embeds an HTML5 iframe pointing directly to the Guacamole client tunnel using an ephemeral authentication token.
4. Users interact with full graphical Windows desktops or Linux terminals directly inside any modern web browser.

#### Guacamole Gateway Deployment (`docker-compose.guacamole.yml`)

```yaml
version: '3.8'

services:
  guacamole-db:
    image: postgres:15-alpine
    container_name: al-guacamole-db
    restart: always
    environment:
      POSTGRES_DB: guacamole_db
      POSTGRES_USER: guacamole_user
      POSTGRES_PASSWORD: ${GUACAMOLE_DB_PASSWORD:-GuacSecurePass2026!}
    volumes:
      - guac-db-data:/var/lib/postgresql/data
    networks:
      - guac-net

  guacd:
    image: guacamole/guacd:latest
    container_name: al-guacd
    restart: always
    networks:
      - guac-net

  guacamole:
    image: guacamole/guacamole:latest
    container_name: al-guacamole-web
    restart: always
    depends_on:
      - guacamole-db
      - guacd
    environment:
      GUACD_HOSTNAME: guacd
      GUACD_PORT: 4822
      POSTGRESQL_HOSTNAME: guacamole-db
      POSTGRESQL_PORT: 5432
      POSTGRESQL_DATABASE: guacamole_db
      POSTGRESQL_USER: guacamole_user
      POSTGRESQL_PASSWORD: ${GUACAMOLE_DB_PASSWORD:-GuacSecurePass2026!}
    ports:
      - "8443:8080"
    networks:
      - guac-net

volumes:
  guac-db-data:

networks:
  guac-net:
    driver: bridge
```

#### Guacamole Dynamic Connection Injector (`02_Register_Guacamole_Connection.ps1`)

```powershell
<#
.SYNOPSIS
    Registers a newly provisioned AutomatedLab VM into Apache Guacamole via REST API.
#>
function Add-GuacamoleConnection {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$GuacamoleUrl = "http://localhost:8443/guacamole",

        [Parameter(Mandatory = $true)]
        [string]$AdminUser = "guacadmin",

        [Parameter(Mandatory = $true)]
        [string]$AdminPassword = "guacadmin",

        [Parameter(Mandatory = $true)]
        [string]$ConnectionName,

        [Parameter(Mandatory = $true)]
        [string]$HostnameOrIp,

        [Parameter(Mandatory = $true)]
        [ValidateSet("rdp", "ssh")]
        [string]$Protocol,

        [Parameter(Mandatory = $false)]
        [string]$Username,

        [Parameter(Mandatory = $false)]
        [string]$Password
    )

    # 1. Obtain Guacamole Auth Token
    $AuthBody = @{
        username = $AdminUser
        password = $AdminPassword
    }
    $TokenResponse = Invoke-RestMethod -Uri "$GuacamoleUrl/api/tokens" -Method Post -Body $AuthBody
    $AuthToken = $TokenResponse.authToken
    $DataSource = $TokenResponse.dataSource

    # 2. Construct Protocol Parameters
    $Parameters = @{
        "hostname" = $HostnameOrIp
        "port"     = if ($Protocol -eq "rdp") { "3389" } else { "22" }
        "ignore-cert" = "true"
    }

    if ($Protocol -eq "rdp") {
        $Parameters["security"] = "any"
        $Parameters["resize-method"] = "display-update"
        $Parameters["enable-drive"] = "true"
        $Parameters["drive-path"] = "/tmp/guac-share"
        if ($Username) { $Parameters["username"] = $Username }
        if ($Password) { $Parameters["password"] = $Password }
    } elseif ($Protocol -eq "ssh") {
        if ($Username) { $Parameters["username"] = $Username }
        if ($Password) { $Parameters["password"] = $Password }
    }

    $ConnectionPayload = @{
        name       = $ConnectionName
        protocol   = $Protocol
        parameters = $Parameters
    } | ConvertTo-Json -Depth 5

    # 3. Create Connection Entry
    $Headers = @{ "Guacamole-Token" = $AuthToken }
    $NewConn = Invoke-RestMethod -Uri "$GuacamoleUrl/api/session/data/$DataSource/connections" `
                                 -Method Post `
                                 -Headers $Headers `
                                 -ContentType "application/json" `
                                 -Body $ConnectionPayload

    Write-Host "[+] Registered Guacamole Connection '$ConnectionName' with ID $($NewConn.identifier)" -ForegroundColor Green

    # Return connection iframe URL
    return "$GuacamoleUrl/#/client/$( [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("$($NewConn.identifier)`0c`0$DataSource")) )?token=$AuthToken"
}
```

---

## 3. Phase 2: Custom Application Delivery & Container Automation

### 3.1 Custom Service / App Upload & Remote Install Engine

#### Functional Specification
The Custom Application Delivery engine allows operators to upload proprietary installation packages (`.exe`, `.msi`, `.zip`, `.ps1`) through the PowerShell Universal web portal. The engine catalogs the artifact, calculates its SHA256 checksum, generates an automated silent-installation wrapper, and injects it into target VMs using AutomatedLab's `Invoke-LabCommand` via PowerShell Direct (VMBus) or WinRM.

#### Package Manifest Standard (`app-manifest.json`)
Every custom application registered in `LabSources\CustomUploads` receives a descriptor file:

```json
{
  "PackageId": "Internal-PaymentGateway-Service",
  "Version": "2.4.1",
  "InstallerType": "MSI",
  "BinaryFileName": "PaymentGatewayServiceSetup-2.4.1.msi",
  "SHA256": "4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a",
  "SilentInstallArguments": "/qn /norestart ALLUSERS=1 INSTALLDIR="C:\Program Files\PaymentGateway"",
  "ServiceDependencies": ["W32Time", "LanmanServer"],
  "PostInstallVerificationScript": "Get-Service -Name PaymentGateway | Should -Be 'Running'"
}
```

#### Upload API & In-Guest Deployment Pipeline (`03_Custom_Service_App_Delivery.ps1`)

```powershell
<#
.SYNOPSIS
    PowerShell Universal Backend Endpoint and Execution Pipeline for Custom App Deployments.
#>

# PSU API Endpoint: Handle File Upload
New-PSUEndpoint -Url "/api/v1/apps/upload" -Method "POST" -Endpoint {
    param($Request)

    $UploadDir = "V:\LabSources\CustomUploads"
    if (-not (Test-Path $UploadDir)) { New-Item -Path $UploadDir -ItemType Directory -Force }

    $FileName = $Request.Headers["X-File-Name"]
    $TargetPath = Join-Path $UploadDir $FileName

    # Stream binary content to destination
    [System.IO.File]::WriteAllBytes($TargetPath, $Request.Body)
    $FileHash = (Get-FileHash -Path $TargetPath -Algorithm SHA256).Hash

    @{
        Status   = "Success"
        FileName = $FileName
        FilePath = $TargetPath
        SHA256   = $FileHash
    } | ConvertTo-Json
}

# AutomatedLab Injection Engine
function Install-CustomLabApplication {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$LabName,

        [Parameter(Mandatory = $true)]
        [string]$ComputerName,

        [Parameter(Mandatory = $true)]
        [string]$PackageFileName,

        [Parameter(Mandatory = $true)]
        [string]$SilentArgs,

        [Parameter(Mandatory = $false)]
        [ValidateSet("MSI", "EXE", "Script")]
        [string]$InstallerType = "MSI"
    )

    Import-Lab -Name $LabName
    $SourcePath = "V:\LabSources\CustomUploads\$PackageFileName"

    if (-not (Test-Path $SourcePath)) {
        throw "Binary package '$PackageFileName' was not found in LabSources."
    }

    Write-Host "[-] Staging '$PackageFileName' to VM '$ComputerName' via VMBus/PowerShell Direct..." -ForegroundColor Cyan
    Copy-LabFileFilter -Path $SourcePath -DestinationPath "C:\Installers" -ComputerName $ComputerName

    Write-Host "[-] Executing silent installation..." -ForegroundColor Cyan
    $InstallScriptBlock = {
        param($PkgFile, $Args, $Type)
        $LocalFile = "C:\Installers\$PkgFile"

        switch ($Type) {
            "MSI" {
                $Process = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$LocalFile`" $Args" -Wait -PassThru
                if ($Process.ExitCode -notin @(0, 3010)) { throw "MSI install failed with code: $($Process.ExitCode)" }
            }
            "EXE" {
                $Process = Start-Process -FilePath $LocalFile -ArgumentList $Args -Wait -PassThru
                if ($Process.ExitCode -notin @(0, 3010)) { throw "EXE install failed with code: $($Process.ExitCode)" }
            }
            "Script" {
                & (Join-Path "C:\Installers" $PkgFile)
            }
        }
    }

    Invoke-LabCommand -ComputerName $ComputerName `
                      -ScriptBlock $InstallScriptBlock `
                      -ArgumentList $PackageFileName, $SilentArgs, $InstallerType `
                      -ErrorAction Stop

    Write-Host "[OK] Successfully deployed '$PackageFileName' onto '$ComputerName'." -ForegroundColor Green
}
```

---

### 3.2 1-Click Docker Compose Generator & Cryptographic Secret Engine

#### Feature Overview
The Docker Compose Generator provides a single-click orchestration pipeline that provisions a modern container environment on a target Linux or Windows host:
1. **Interactive Visual Topology Selection:** Users pick base service stacks (e.g., PostgreSQL, Redis, NGINX Reverse Proxy, RabbitMQ, Custom App Container).
2. **Automated Cryptographic Variable Generation:** Generates high-entropy passwords, tokens, API keys, and cookie salts using `System.Security.Cryptography.RandomNumberGenerator`.
3. **Hardened `docker-compose.yml` Output:** Emits a multi-container YAML specification with healthchecks, isolated networks, volume mappings, and security limits.
4. **Environment File (`.env`) Decoupling:** Separates sensitive credentials from compose manifests.

#### Docker Compose & Cryptographic Secret Generator (`04_Docker_Compose_Keeper_Generator.py`)

```powershell
<#
.SYNOPSIS
    1-Click Docker Compose Generator with Cryptographic Secrets and Keeper Export.
#>

class SecretGenerator {
    static [string] GeneratePassword([int]$Length, [bool]$IncludeSymbols = $true) {
        $Chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        if ($IncludeSymbols) { $Chars += "!@#$%^&*()-_=+[]{}<>" }
        
        $Bytes = [byte[]]::new($Length)
        $Rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        $Rng.GetBytes($Bytes)
        
        $Result = [char[]]::new($Length)
        for ($i = 0; $i -lt $Length; $i++) {
            $Result[$i] = $Chars[$Bytes[$i] % $Chars.Length]
        }
        return [string]::new($Result)
    }

    static [string] GenerateHexToken([int]$ByteCount = 32) {
        $Bytes = [byte[]]::new($ByteCount)
        $Rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        $Rng.GetBytes($Bytes)
        return -join ($Bytes | ForEach-Object { "{0:x2}" -f $_ })
    }
}

function New-DockerComposeStack {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ProjectName,

        [Parameter(Mandatory = $true)]
        [string]$OutputDirectory,

        [Parameter(Mandatory = $false)]
        [switch]$IncludePostgres,

        [Parameter(Mandatory = $false)]
        [switch]$IncludeRedis,

        [Parameter(Mandatory = $false)]
        [switch]$IncludeNginx
    )

    if (-not (Test-Path $OutputDirectory)) { New-Item -Path $OutputDirectory -ItemType Directory -Force | Out-Null }

    $EnvVariables = [ordered]@{}
    $ComposeServices = [ordered]@{}
    $Volumes = [ordered]@{}

    # 1. PostgreSQL Service Definition
    if ($IncludePostgres) {
        $PgUser = "al_db_user"
        $PgPass = [SecretGenerator]::GeneratePassword(24, $false)
        $PgDb   = "$($ProjectName)_production"
        
        $EnvVariables["POSTGRES_USER"] = $PgUser
        $EnvVariables["POSTGRES_PASSWORD"] = $PgPass
        $EnvVariables["POSTGRES_DB"] = $PgDb

        $ComposeServices["postgres"] = @{
            image = "postgres:16-alpine"
            container_name = "$($ProjectName)-postgres"
            restart = "unless-stopped"
            environment = @(
                "POSTGRES_USER=${POSTGRES_USER}",
                "POSTGRES_PASSWORD=${POSTGRES_PASSWORD}",
                "POSTGRES_DB=${POSTGRES_DB}"
            )
            volumes = @("postgres_data:/var/lib/postgresql/data")
            networks = @("app-network")
            healthcheck = @{
                test = @("CMD-SHELL", "pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}")
                interval = "10s"
                timeout = "5s"
                retries = 5
            }
        }
        $Volumes["postgres_data"] = @{ driver = "local" }
    }

    # 2. Redis Cache Service Definition
    if ($IncludeRedis) {
        $RedisPass = [SecretGenerator]::GeneratePassword(32, $false)
        $EnvVariables["REDIS_PASSWORD"] = $RedisPass

        $ComposeServices["redis"] = @{
            image = "redis:7.2-alpine"
            container_name = "$($ProjectName)-redis"
            restart = "unless-stopped"
            command = "redis-server --requirepass ${REDIS_PASSWORD}"
            volumes = @("redis_data:/data")
            networks = @("app-network")
        }
        $Volumes["redis_data"] = @{ driver = "local" }
    }

    # 3. NGINX Reverse Proxy
    if ($IncludeNginx) {
        $ComposeServices["nginx"] = @{
            image = "nginx:alpine"
            container_name = "$($ProjectName)-nginx"
            restart = "unless-stopped"
            ports = @("80:80", "443:443")
            volumes = @(
                "./nginx.conf:/etc/nginx/nginx.conf:ro"
            )
            networks = @("app-network")
        }
    }

    # 4. Generate Additional Application Cryptographic Tokens
    $EnvVariables["APP_SECRET_KEY"] = [SecretGenerator]::GenerateHexToken(32)
    $EnvVariables["API_AUTH_TOKEN"] = [SecretGenerator]::GeneratePassword(40, $true)

    # 5. Write .env File
    $EnvFilePath = Join-Path $OutputDirectory ".env"
    $EnvFileContent = $EnvVariables.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }
    $EnvFileContent | Set-Content -Path $EnvFilePath -Encoding UTF8

    # 6. Write docker-compose.yml
    $ComposeObject = @{
        version = "3.8"
        services = $ComposeServices
        volumes = $Volumes
        networks = @{
            "app-network" = @{ driver = "bridge" }
        }
    }

    # Serialize to YAML using PowerShell (or ConvertTo-Json as intermediary)
    $ComposeFilePath = Join-Path $OutputDirectory "docker-compose.yml"
    $YamlLines = @("version: '3.8'", "", "services:")
    
    foreach ($ServiceName in $ComposeServices.Keys) {
        $Svc = $ComposeServices[$ServiceName]
        $YamlLines += "  $ServiceName`:"
        $YamlLines += "    image: $($Svc.image)"
        $YamlLines += "    container_name: $($Svc.container_name)"
        $YamlLines += "    restart: $($Svc.restart)"
        if ($Svc.command) { $YamlLines += "    command: $($Svc.command)" }
        if ($Svc.ports) {
            $YamlLines += "    ports:"
            foreach ($P in $Svc.ports) { $YamlLines += "      - '$P'" }
        }
        if ($Svc.environment) {
            $YamlLines += "    environment:"
            foreach ($E in $Svc.environment) { $YamlLines += "      - $E" }
        }
        if ($Svc.volumes) {
            $YamlLines += "    volumes:"
            foreach ($V in $Svc.volumes) { $YamlLines += "      - $V" }
        }
        if ($Svc.networks) {
            $YamlLines += "    networks:"
            foreach ($N in $Svc.networks) { $YamlLines += "      - $N" }
        }
        if ($Svc.healthcheck) {
            $YamlLines += "    healthcheck:"
            $YamlLines += "      test: [ '$($Svc.healthcheck.test -join "', '")' ]"
            $YamlLines += "      interval: $($Svc.healthcheck.interval)"
            $YamlLines += "      timeout: $($Svc.healthcheck.timeout)"
            $YamlLines += "      retries: $($Svc.healthcheck.retries)"
        }
        $YamlLines += ""
    }

    if ($Volumes.Count -gt 0) {
        $YamlLines += "volumes:"
        foreach ($Vol in $Volumes.Keys) { $YamlLines += "  $Vol`: {}" }
        $YamlLines += ""
    }

    $YamlLines += "networks:"
    $YamlLines += "  app-network:"
    $YamlLines += "    driver: bridge"

    $YamlLines | Set-Content -Path $ComposeFilePath -Encoding UTF8
    Write-Host "[+] Wrote docker-compose.yml to: $ComposeFilePath" -ForegroundColor Green
    Write-Host "[+] Wrote .env to: $EnvFilePath" -ForegroundColor Green

    return @{
        Directory = $OutputDirectory
        Secrets   = $EnvVariables
    }
}
```

---

### 3.3 Keeper Security Vault Export & Integration Engine

#### Schema Compliance & Integration Architecture
To safely store and rotate all generated credentials, the stack includes a **Keeper Security Export Engine**. The engine outputs an official Keeper JSON structure conforming to the Keeper Password Manager and Keeper Commander schema:
* Supported record types: `login`, `databaseCredentials`, `encryptedNotes`.
* Categorized hierarchy: Organizes secrets under dedicated private or shared folders (e.g., `AutomatedLab_Environments\{ProjectName}`).
* Custom fields mapping: Maps runtime parameters, ports, hosts, API tokens, and secret keys as typed metadata.

#### Keeper JSON Generator (`Export-KeeperSecrets.ps1`)

```powershell
<#
.SYNOPSIS
    Exports generated Docker Compose and Lab Secrets into Keeper-compatible JSON.
.DESCRIPTION
    Complies with Keeper Desktop Vault, Web Vault, and Keeper Commander JSON Import schemas.
#>
function Export-KeeperSecrets {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ProjectName,

        [Parameter(Mandatory = $true)]
        [hashtable]$GeneratedSecrets,

        [Parameter(Mandatory = $false)]
        [string]$TargetHostIp = "192.168.10.50",

        [Parameter(Mandatory = $true)]
        [string]$ExportFilePath
    )

    $FolderPath = "AutomatedLab_Vault\$ProjectName"
    $Records = @()

    # 1. PostgreSQL Database Credential Record
    if ($GeneratedSecrets.ContainsKey("POSTGRES_PASSWORD")) {
        $DbRecord = @{
            title         = "$ProjectName - PostgreSQL Database"
            "$type"       = "databaseCredentials"
            login         = $GeneratedSecrets["POSTGRES_USER"]
            password      = $GeneratedSecrets["POSTGRES_PASSWORD"]
            login_url     = "postgresql://$TargetHostIp`:5432/$($GeneratedSecrets['POSTGRES_DB'])"
            notes         = "Auto-generated by AutomatedLab Docker Compose Engine."
            custom_fields = @{
                "Database Engine" = "PostgreSQL 16"
                "Database Name"   = $GeneratedSecrets["POSTGRES_DB"]
                "Port"            = "5432"
                "Target Host"     = $TargetHostIp
            }
            folders       = @(
                @{ folder = $FolderPath }
            )
        }
        $Records += $DbRecord
    }

    # 2. Redis Cache Credential Record
    if ($GeneratedSecrets.ContainsKey("REDIS_PASSWORD")) {
        $RedisRecord = @{
            title         = "$ProjectName - Redis Cache"
            "$type"       = "login"
            login         = "default"
            password      = $GeneratedSecrets["REDIS_PASSWORD"]
            login_url     = "redis://$TargetHostIp`:6379"
            notes         = "Auto-generated Redis authentication token."
            custom_fields = @{
                "Port"        = "6379"
                "Target Host" = $TargetHostIp
            }
            folders       = @(
                @{ folder = $FolderPath }
            )
        }
        $Records += $RedisRecord
    }

    # 3. Application API Tokens & Cryptographic Keys
    $CustomApiFields = @{}
    if ($GeneratedSecrets.ContainsKey("APP_SECRET_KEY")) {
        $CustomApiFields["APP_SECRET_KEY"] = $GeneratedSecrets["APP_SECRET_KEY"]
    }
    if ($GeneratedSecrets.ContainsKey("API_AUTH_TOKEN")) {
        $CustomApiFields["API_AUTH_TOKEN"] = $GeneratedSecrets["API_AUTH_TOKEN"]
    }

    if ($CustomApiFields.Count -gt 0) {
        $AppRecord = @{
            title         = "$ProjectName - Application Secrets & Environment Keys"
            "$type"       = "login"
            login         = "api_admin"
            password      = $GeneratedSecrets["API_AUTH_TOKEN"]
            notes         = "High-entropy application master keys and salt strings."
            custom_fields = $CustomApiFields
            folders       = @(
                @{ folder = $FolderPath }
            )
        }
        $Records += $AppRecord
    }

    # 4. Construct Final Keeper JSON Structure
    $KeeperExportPayload = @{
        records = $Records
    }

    $JsonData = $KeeperExportPayload | ConvertTo-Json -Depth 6
    [System.IO.File]::WriteAllText($ExportFilePath, $JsonData, [System.Text.Encoding]::UTF8)

    Write-Host "[OK] Keeper-compatible secrets exported to: $ExportFilePath" -ForegroundColor Green
    return $ExportFilePath
}
```

#### Sample Generated `keeper_export.json`
```json
{
  "records": [
    {
      "title": "AlphaDevLab - PostgreSQL Database",
      "$type": "databaseCredentials",
      "login": "al_db_user",
      "password": "qF9wK2mP7xZ5vR8cT1yU4bN0",
      "login_url": "postgresql://192.168.10.50:5432/AlphaDevLab_production",
      "notes": "Auto-generated by AutomatedLab Docker Compose Engine.",
      "custom_fields": {
        "Database Engine": "PostgreSQL 16",
        "Database Name": "AlphaDevLab_production",
        "Port": "5432",
        "Target Host": "192.168.10.50"
      },
      "folders": [
        {
          "folder": "AutomatedLab_Vault\AlphaDevLab"
        }
      ]
    },
    {
      "title": "AlphaDevLab - Redis Cache",
      "$type": "login",
      "login": "default",
      "password": "M8kL1vX4aT9sR2pW6yQ0bZ3cE5nU7hJ9",
      "login_url": "redis://192.168.10.50:6379",
      "notes": "Auto-generated Redis authentication token.",
      "custom_fields": {
        "Port": "6379",
        "Target Host": "192.168.10.50"
      },
      "folders": [
        {
          "folder": "AutomatedLab_Vault\AlphaDevLab"
        }
      ]
    },
    {
      "title": "AlphaDevLab - Application Secrets & Environment Keys",
      "$type": "login",
      "login": "api_admin",
      "password": "4f9e3d8b1c7a2e5f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d",
      "notes": "High-entropy application master keys and salt strings.",
      "custom_fields": {
        "APP_SECRET_KEY": "8a7c6b5d4e3f2a1b0c9d8e7f6a5b4c3d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b",
        "API_AUTH_TOKEN": "K9#m$L2!vP5*xR8@bT1&yU4(cZ7)eW0-"
      },
      "folders": [
        {
          "folder": "AutomatedLab_Vault\AlphaDevLab"
        }
      ]
    }
  ]
}
```

---

## 4. End-to-End Operational Workflow Runbook

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                   Step-by-Step Operator Journey                                  │
│                                                                                                  │
│   [1. Define Lab & Storage]                                                                      │
│       Select VM Topologies ──> ReFS Block Cloning Hydrates Base Disks (< 30s)                    │
│                                                                                                  │
│   [2. Deploy Custom Software]                                                                    │
│       Upload Installer via PSU ──> SHA256 Check ──> Injected via VMBus / WinRM                   │
│                                                                                                  │
│   [3. 1-Click Container Generation]                                                              │
│       Select Services (Postgres, Redis, Nginx) ──> Cryptographic Entropy Engine                  │
│                                                                                                  │
│   [4. Manifest & Secret Decoupling]                                                              │
│       Generate `docker-compose.yml` + `.env` on Host ──> Containers Deploy & Verify               │
│                                                                                                  │
│   [5. Secure Credential Handshake]                                                               │
│       Emit `keeper_secrets_export.json` ──> Operator Imports to Keeper Vault                     │
│                                                                                                  │
│   [6. Interactive In-Browser Access]                                                             │
│       Guacamole Registers VM IP ──> Operator Opens HTML5 RDP/SSH Console in PSU                  │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 4.1 Step 1: Ingesting Custom Applications via PowerShell Universal
1. Log into the PowerShell Universal portal at `https://labs.internal.net`.
2. Navigate to **Lab Catalog > Custom Artifacts**.
3. Drag-and-drop the required software package (e.g., `PaymentGatewayServiceSetup-2.4.1.msi`).
4. Select the silent install profile or provide custom command-line flags. The package is cryptographically hashed and copied to `V:\LabSources\CustomUploads`.

### 4.2 Step 2: Running the 1-Click Docker Compose Generator
1. Navigate to **Automation Studio > Container Stacks**.
2. Click **New Container Stack**:
   * Name: `BillingMicroservices`
   * Target Host VM: `APP-SRV-01` (Ubuntu 24.04 Guest)
   * Toggle Services: **PostgreSQL**, **Redis**, **NGINX**.
3. Click **Generate & Stage Stack**.
4. The backend worker:
   * Generates 256-bit entropy credentials.
   * Compiles `docker-compose.yml` and `.env`.
   * Automatically executes `docker compose up -d` on `APP-SRV-01` via SSH / PowerShell Direct.
   * Streams live container healthcheck statuses back to the web console.

### 4.3 Step 3: Importing Credentials into Keeper Security
Operators can import the generated secrets into Keeper using two distinct methods:

#### Method A: Keeper Web Vault / Desktop App (GUI)
1. In the PowerShell Universal UI, click **Download Keeper Export (`.json`)**.
2. Open the **Keeper Desktop App** or log into the **Keeper Web Vault**.
3. Click on your profile menu in the upper-right corner and select **Settings > Import**.
4. In the format dropdown, select **Keeper JSON**.
5. Drag and drop the downloaded `keeper_export.json` file.
6. Review the folder tree structure (`AutomatedLab_Vault\BillingMicroservices`) and click **Import Records**. All passwords, URLs, database credentials, and custom API tokens are instantly populated in your encrypted vault.

#### Method B: Keeper Commander CLI (Headless / Automated Pipeline)
For programmatic CI/CD environments, pipe the export directly into Keeper Commander:

```bash
# Authenticate Keeper Commander session
keeper login admin@enterprise.com

# Headless import into target vault
keeper import --format=json --filter=all keeper_export.json

# Verify imported records
keeper search "BillingMicroservices"
```

### 4.4 Step 4: Accessing Deployed Virtual Machines via Guacamole
1. In the PSU Web Dashboard, navigate to **Active Labs > Lab Instances**.
2. Locate the active virtual machine (e.g., `DC-01` or `APP-SRV-01`).
3. Click **Open Console**.
4. An integrated HTML5 window launches directly within the tab, connecting through Apache Guacamole over port 8443 (via HTTPS) without requiring client software, RDP clients, or firewall changes.

---

## 5. Security & Hardening Checklist

| Domain | Control Policy | Verification Method |
| :--- | :--- | :--- |
| **Storage Security** | BitLocker encryption on ReFS Volume `V:` | `Get-BitLockerVolume -MountPoint "V:"` |
| **Service Execution** | PSU Engine runs under host gMSA | Verify service user matches `DOMAINl_psu_svc$` |
| **Network Boundary** | Hyper-V NAT switch blocks inbound RFC1918 leaks | Inspect NAT rules via `Get-NetNat` |
| **Container Isolation** | Docker containers run with non-root UID | Inspect `SecurityOpt` in compose output |
| **Secret Hygiene** | Ephemeral `.env` files wiped post-Keeper import | Automated cleanup trigger via PSU scheduled job |
| **Audit Logging** | Guacamole and PSU operations shipped to SIEM | Forward Windows Event Logs & Docker journald |
