# AutomatedLab Platform — Linux Deployment

Deploys the **containerized control plane** (PowerShell Universal + Apache Guacamole + Caddy
reverse proxy + AUTOMATElab dashboard) on Linux via Docker Compose.

> The Hyper-V / AutomatedLab **lab-provisioning engine is Windows-only** and runs separately on a
> Windows Server / Windows 11 Pro host. This Linux stack is the browser-facing control plane,
> HTML5 console gateway, and dashboard.

## Quick start

```bash
cd automatedlab-platform/linux
chmod +x install.sh deploy.sh setup.sh
sudo ./setup.sh          # install Docker + Compose + Python, then deploy
```

Or step-by-step:

```bash
sudo ./install.sh        # 1. Docker Engine + Compose v2 + Python 3
./deploy.sh              # 2. generate .env + docker compose up -d
```

## URLs after deploy

| Service | URL |
| :--- | :--- |
| AUTOMATElab dashboard | `http://localhost/` |
| PowerShell Universal | `http://localhost:5000` |
| Guacamole console | `http://localhost/guacamole` (default `guacadmin/guacadmin`) |
| AutomatedLab Studio | Windows host: `http://<windows-host>:5000/automatedlab` |

## Supported distros

- Debian / Ubuntu
- RHEL / CentOS / Fedora / Rocky / AlmaLinux

## Lab lifecycle (OpenTofu)

```bash
cd automatedlab-platform/linux
chmod +x lab.sh
./lab.sh check                                   # compile + tofu plan smoke test
./lab.sh deploy ../tofu/examples/sample-graph.json docker mylab 8
./lab.sh list
./lab.sh destroy mylab
```

## Operations

```bash
cd ../docker
docker compose ps                # status
docker compose logs -f psu       # follow PSU logs
docker compose down              # stop (keeps data)
docker compose down -v           # stop + DELETE all data
docker compose --profile generator run --rm generator   # 1-click Compose/Keeper generator
```

## Notes

- `.env` is auto-generated with random secrets on first deploy and kept (chmod 600).
- The `/automatedlab` app and `/api/v1/automatelab/*` endpoints live on the **Windows host's**
  PowerShell Universal; the Linux PSU container serves its own dashboard and API.
