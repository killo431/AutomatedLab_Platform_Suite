#!/usr/bin/env bash
set -euo pipefail

# AutomatedLab Platform — Linux prerequisites installer.
# Installs Docker Engine + Docker Compose v2 + Python 3. Idempotent.
# Usage: sudo ./install.sh

C='\033[36m'; G='\033[32m'; Y='\033[33m'; R='\033[31m'; N='\033[0m'
log(){ echo -e "${C}[-]${N} $*"; }
ok(){  echo -e "${G}[OK]${N} $*"; }
warn(){ echo -e "${Y}[!]${N} $*"; }
die(){ echo -e "${R}[ERR]${N} $*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "Run as root (sudo)."

# shellcheck disable=SC1091
. /etc/os-release 2>/dev/null || true
log "Detected OS: ${PRETTY_NAME:-unknown} (${ID:-unknown})"

# 1. Docker Engine + Compose v2 plugin
if command -v docker >/dev/null 2>&1; then
  ok "Docker already installed: $(docker --version 2>/dev/null || true)"
else
  log "Installing Docker Engine + Compose plugin..."
  case "${ID:-}" in
    ubuntu|debian)
      apt-get update -y
      apt-get install -y ca-certificates curl gnupg
      install -m 0755 -d /etc/apt/keyrings
      curl -fsSL "https://download.docker.com/linux/${ID}/gpg" | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
      chmod a+r /etc/apt/keyrings/docker.gpg
      echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/${ID} ${VERSION_CODENAME} stable" > /etc/apt/sources.list.d/docker.list
      apt-get update -y
      apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
      ;;
    rhel|centos|fedora|rocky|almalinux)
      dnf -y install dnf-plugins-core
      dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
      dnf -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
      ;;
    *)
      die "Unsupported distro '${ID}'. Install Docker manually: https://docs.docker.com/engine/install/"
      ;;
  esac
  systemctl enable --now docker
  ok "Docker Engine installed."
fi

systemctl enable --now docker 2>/dev/null || true

# 2. Docker Compose v2 (fallback standalone if plugin missing)
if docker compose version >/dev/null 2>&1; then
  ok "Docker Compose v2 available: $(docker compose version 2>/dev/null | head -n1)"
else
  warn "Compose plugin missing; installing standalone binary..."
  COMPOSE_BIN="/usr/local/lib/docker/cli-plugins/docker-compose"
  mkdir -p "$(dirname "$COMPOSE_BIN")"
  curl -fsSL "https://github.com/docker/compose/releases/latest/download/docker-compose-linux-$(uname -m)" -o "$COMPOSE_BIN"
  chmod +x "$COMPOSE_BIN"
  ok "Docker Compose installed."
fi

# 3. Python 3 + pip
if command -v python3 >/dev/null 2>&1; then
  ok "Python3 available: $(python3 --version 2>/dev/null || true)"
else
  log "Installing Python 3..."
  case "${ID:-}" in
    ubuntu|debian) apt-get install -y python3 python3-pip ;;
    rhel|centos|fedora|rocky|almalinux) dnf -y install python3 python3-pip ;;
  esac
  ok "Python3 installed."
fi

# 4. OpenTofu
if command -v tofu >/dev/null 2>&1; then
  ok "OpenTofu available: $(tofu --version 2>/dev/null | head -n1)"
else
  log "Installing OpenTofu..."
  case "${ID:-}" in
    ubuntu|debian) METHOD=deb ;;
    rhel|centos|fedora|rocky|almalinux) METHOD=rpm ;;
    *) METHOD=standalone ;;
  esac
  curl -fsSL https://get.opentofu.org/install-opentofu.sh -o /tmp/install-opentofu.sh
  sh /tmp/install-opentofu.sh --install-method "$METHOD"
  ok "OpenTofu installed."
fi

# 5. Add invoking user to docker group (avoid sudo for docker)
if [ -n "${SUDO_USER:-}" ]; then
  usermod -aG docker "$SUDO_USER" 2>/dev/null || true
  ok "Added ${SUDO_USER} to the docker group (log out/in to take effect)."
fi

echo
ok "Prerequisites ready. Next: ./setup.sh (or ./deploy.sh if already installed)."
