#!/usr/bin/env bash
set -euo pipefail

# AutomatedLab Platform — Linux lab lifecycle via OpenTofu.
#   ./lab.sh deploy <graph.json> [docker|proxmox] [name] [hours]
#   ./lab.sh destroy <name>
#   ./lab.sh list
#   ./lab.sh check

C='\033[36m'; G='\033[32m'; Y='\033[33m'; R='\033[31m'; N='\033[0m'
log(){ echo -e "${C}[-]${N} $*"; }
ok(){  echo -e "${G}[OK]${N} $*"; }
warn(){ echo -e "${Y}[!]${N} $*"; }
die(){ echo -e "${R}[ERR]${N} $*" >&2; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
COMPILER="$PLATFORM_DIR/tofu/graph_to_hcl.py"
STATE_DIR="$PLATFORM_DIR/docker/data"
REGISTRY="$STATE_DIR/LabRegistry.json"
mkdir -p "$STATE_DIR"

command -v tofu >/dev/null 2>&1 || die "tofu not found — run ./install.sh first."
command -v python3 >/dev/null 2>&1 || die "python3 not found."

registry_read()  { [ -f "$REGISTRY" ] && cat "$REGISTRY" || echo '[]'; }
registry_write() { cat > "$REGISTRY"; }

registry_add() {
  NAME="$1" PROVIDER="$2" EXPIRES="$3" HOURS="$4" python3 -c '
import sys, json, os
d = json.load(sys.stdin)
d = [x for x in d if x.get("LabName") != os.environ["NAME"]]
d.append({
  "LabName": os.environ["NAME"],
  "Provider": os.environ["PROVIDER"],
  "ExpiresAt": os.environ["EXPIRES"],
  "RegisteredAt": os.environ["EXPIRES"],
  "LeaseHours": int(os.environ["HOURS"]),
})
print(json.dumps(d, indent=2))
'
}

registry_remove() {
  NAME="$1" python3 -c '
import sys, json, os
d = json.load(sys.stdin)
d = [x for x in d if x.get("LabName") != os.environ["NAME"]]
print(json.dumps(d, indent=2))
'
}

deploy() {
  local graph="${1:?graph.json required}"
  local provider="${2:-docker}"
  local name="${3:-}"
  local hours="${4:-8}"
  [ -f "$graph" ] || die "graph not found: $graph"

  if [ -z "$name" ]; then
    name="$(python3 -c "import json;print(json.load(open('$graph'))['labName'])" 2>/dev/null || true)"
    [ -z "$name" ] && name="$(basename "$graph" .json)"
  fi

  local outdir="$STATE_DIR/labs/$name"
  mkdir -p "$outdir"
  log "Compiling $graph -> HCL (provider=$provider) in $outdir"
  python3 "$COMPILER" --input "$graph" --provider "$provider" --outdir "$outdir"

  log "tofu init + apply"
  ( cd "$outdir" && tofu init -input=false && tofu apply -auto-approve -input=false )

  local expires
  expires="$(date -Iseconds -d "+${hours} hours" 2>/dev/null || date -Iseconds)"
  registry_add "$name" "$provider" "$expires" "$hours" | registry_write
  ok "Lab '$name' deployed (provider=$provider, expires $expires)."
}

destroy() {
  local name="${1:?name required}"
  local outdir="$STATE_DIR/labs/$name"
  [ -d "$outdir" ] || die "lab not found: $name"

  log "tofu destroy ($name)"
  ( cd "$outdir" && tofu destroy -auto-approve -input=false ) || warn "destroy returned non-zero (already gone?)"
  rm -rf "$outdir"
  registry_remove "$name" | registry_write
  ok "Lab '$name' destroyed."
}

list() {
  registry_read | python3 -m json.tool
}

check() {
  local outdir="$STATE_DIR/.check"
  mkdir -p "$outdir"
  log "Round-trip smoke: compile sample graph + tofu plan (docker)"
  python3 "$COMPILER" --input "$PLATFORM_DIR/tofu/examples/sample-graph.json" --provider docker --outdir "$outdir"
  ( cd "$outdir" && tofu init -input=false >/dev/null && tofu plan -input=false )
  ok "Check passed."
}

case "${1:-}" in
  deploy)  shift; [ $# -ge 1 ] || die "usage: lab.sh deploy <graph.json> [docker|proxmox] [name] [hours]"; deploy "$@" ;;
  destroy) shift; [ $# -ge 1 ] || die "usage: lab.sh destroy <name>"; destroy "$1" ;;
  list)    list ;;
  check)   check ;;
  *) echo "usage: $0 {deploy|destroy|list|check} ..."; exit 1 ;;
esac
