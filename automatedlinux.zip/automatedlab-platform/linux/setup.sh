#!/usr/bin/env bash
set -euo pipefail

# AutomatedLab Platform — one-command Linux automatic setup + deploy.
# Usage: sudo ./setup.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo
echo "=============================================================="
echo " AUTOMATEDLAB PLATFORM — LINUX AUTOMATIC SETUP"
echo "=============================================================="
echo

"$SCRIPT_DIR/install.sh"
"$SCRIPT_DIR/deploy.sh"

echo
echo "Setup complete."
