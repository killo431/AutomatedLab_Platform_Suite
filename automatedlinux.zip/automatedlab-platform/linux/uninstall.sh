#!/usr/bin/env bash
set -euo pipefail

# AutomatedLab Platform — Linux teardown / uninstall.
#   ./uninstall.sh                  stop stack (keep data + .env)
#   ./uninstall.sh --purge          also delete volumes + .env (DESTRUCTIVE)
#   ./uninstall.sh --remove-docker  also uninstall Docker + Compose + Python
#   -y|--yes                        skip confirmation prompts

C='\033[36m'; G='\033[32m'; Y='\033[33m'; R='\033[31m'; N='\033[0m'
log(){ echo -e "${C}[-]${N} $*"; }
ok(){  echo -e "${G}[OK]${N} $*"; }
warn(){ echo -e "${Y}[!]${N} $*"; }
die(){ echo -e "${R}[ERR]${N} $*" >&2; exit 1; }

PURGE=false
REMOVE_DOCKER=false
ASSUME_YES=false

for arg in "$@"; do
  case "$arg" in
    --purge) PURGE=true ;;
    --remove-docker) REMOVE_DOCKER=true ;;
    -y|--yes) ASSUME_YES=true ;;
    -h|--help) echo "Usage: $0 [--purge] [--remove-docker] [-y]"; exit 0 ;;
    *) die "Unknown option: $arg" ;;
  esac
done

# shellcheck disable=SC1091
. /etc/os-release 2>/dev/null || true

confirm() {
  if [ "$ASSUME_YES" = true ]; then return 0; fi
  read -r -p "$1 [y/N] " ans
  case "$ans" in
    y|Y) return 0 ;;
    *) return 1 ;;
  esac
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOCKER_DIR="$(cd "$SCRIPT_DIR/../docker" && pwd)"

# 1. Tear down the stack
if command -v docker >/dev/null 2>&1 && [ -f "$DOCKER_DIR/docker-compose.yml" ]; then
  cd "$DOCKER_DIR"
  if [ "$PURGE" = true ]; then
    confirm "Delete all platform data (volumes + .env)? This cannot be undone." || die "Aborted."
    log "Stopping stack and removing volumes..."
    docker compose down -v
    rm -f "$DOCKER_DIR/.env"
    ok "Stack removed (volumes + .env deleted)."
  else
    log "Stopping stack (keeping data + .env)..."
    docker compose down
    ok "Stack stopped."
  fi
else
  warn "docker-compose.yml not found; skipping stack teardown."
fi

# 2. Optional: remove Docker + Python
if [ "$REMOVE_DOCKER" = true ]; then
  [ "$(id -u)" -eq 0 ] || die "--remove-docker requires root (sudo)."
  confirm "Uninstall Docker Engine + Compose + Python from this host?" || die "Aborted."
  log "Removing Docker Engine + Compose + Python..."
  case "${ID:-}" in
    ubuntu|debian)
      apt-get -y purge docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin 2>/dev/null || true
      apt-get -y autoremove --purge 2>/dev/null || true
      rm -f /etc/apt/sources.list.d/docker.list
      rm -f /etc/apt/keyrings/docker.gpg
      apt-get -y purge python3 python3-pip 2>/dev/null || true
      ;;
    rhel|centos|fedora|rocky|almalinux)
      dnf -y remove docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin 2>/dev/null || true
      dnf -y remove python3 python3-pip 2>/dev/null || true
      ;;
    *) warn "Unknown distro '${ID}'; remove Docker/Python manually." ;;
  esac
  ok "Docker + Python removed."
fi

echo
ok "Teardown complete."
