<#
.SYNOPSIS
    Configures dedicated fast storage (ReFS 64KB with NTFS fallback) for Hyper-V and AutomatedLab.
.DESCRIPTION
    Initializes a raw disk and formats it ReFS (64KB block cloning) where supported, falling back
    to NTFS on editions that cannot create ReFS (e.g. Windows 11 Pro). Then sets Hyper-V VM paths
    and registers the AutomatedLab LabSources location. Requires an elevated session.
.PARAMETER DiskNumber
    Disk number of the fast disk to initialize (default 1).
.PARAMETER DriveLetter
    Drive letter assigned to the storage root (default V).
.PARAMETER VolumeLabel
    Volume label (default Lab_FastStorage).
.PARAMETER SkipLabSources
    Skip registering the LabSources location with AutomatedLab.
.EXAMPLE
    .\01_Configure_ReFS_Storage.ps1
.EXAMPLE
    .\01_Configure_ReFS_Storage.ps1 -DiskNumber 2 -DriveLetter S
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [int]$DiskNumber = 1,

    [Parameter(Mandatory = $false)]
    [string]$DriveLetter = "V",

    [Parameter(Mandatory = $false)]
    [string]$VolumeLabel = "Lab_FastStorage",

    [Parameter(Mandatory = $false)]
    [switch]$SkipLabSources
)

$ErrorActionPreference = "Stop"

$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $IsAdmin) {
    throw "01_Configure_ReFS_Storage.ps1 requires an elevated Administrator session."
}

$StorageRoot = "$DriveLetter`:"

# Reuse the volume if it already has a filesystem; otherwise initialize and format.
$existing = Get-Volume -DriveLetter $DriveLetter -ErrorAction SilentlyContinue
if ($existing -and $existing.FileSystem) {
    $storageFs = $existing.FileSystem
    Write-Host "[-] Volume $StorageRoot already exists ($storageFs). Skipping format." -ForegroundColor Yellow
} else {
    Write-Host "[-] Initializing Disk $DiskNumber..." -ForegroundColor Yellow
    Initialize-Disk -Number $DiskNumber -PartitionStyle GPT -ErrorAction SilentlyContinue
    Set-Disk -Number $DiskNumber -IsOffline $false -IsReadOnly $false
    $null = New-Partition -DiskNumber $DiskNumber -UseMaximumSize -DriveLetter $DriveLetter

    try {
        Format-Volume -DriveLetter $DriveLetter -FileSystem ReFS -AllocationUnitSize 65536 -NewFileSystemLabel $VolumeLabel -Confirm:$false | Out-Null
        $storageFs = "ReFS"
        Write-Host "  [OK] $StorageRoot formatted with ReFS (64KB block cloning)." -ForegroundColor Green
    } catch {
        Write-Warning "ReFS creation is not available on this edition (e.g. Windows 11 Pro). Falling back to NTFS."
        Format-Volume -DriveLetter $DriveLetter -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel $VolumeLabel -Confirm:$false | Out-Null
        $storageFs = "NTFS"
        Write-Host "  [OK] $StorageRoot formatted with NTFS (64KB)." -ForegroundColor Yellow
    }
}

if (-not (Test-Path $StorageRoot)) {
    throw "Storage root $StorageRoot is not available."
}

# Hyper-V VM paths (requires an active hypervisor).
$VhdPath = "$StorageRoot\Hyper-V\Virtual Hard Disks"
$VmPath  = "$StorageRoot\Hyper-V\Virtual Machines"
New-Item -Path $VhdPath -ItemType Directory -Force | Out-Null
New-Item -Path $VmPath  -ItemType Directory -Force | Out-Null

$hypervisorPresent = (Get-CimInstance Win32_ComputerSystem).HypervisorPresent
$hyperVModule = Get-Module -ListAvailable -Name Hyper-V -ErrorAction SilentlyContinue
if ($hypervisorPresent -and $hyperVModule) {
    Set-VMHost -VirtualHardDiskPath $VhdPath -VirtualMachinePath $VmPath
    Write-Host "  [OK] Hyper-V VM paths set to $StorageRoot\Hyper-V" -ForegroundColor Green
} else {
    Write-Warning "Hyper-V is not active; skipping Set-VMHost. Re-run after enabling/rebooting Hyper-V."
}

# LabSources structure + AutomatedLab registration.
$LabSourcesRoot = "$StorageRoot\LabSources"
foreach ($Dir in @("ISOs", "SoftwarePackages", "Tools", "CustomUploads", "DockerTemplates")) {
    $p = Join-Path $LabSourcesRoot $Dir
    if (-not (Test-Path $p)) {
        New-Item -Path $p -ItemType Directory -Force | Out-Null
    }
}

if (-not $SkipLabSources) {
    Import-Module AutomatedLab -ErrorAction SilentlyContinue
    if (Get-Command New-LabSourcesFolder -ErrorAction SilentlyContinue) {
        New-LabSourcesFolder -DriveLetter $DriveLetter -ErrorAction SilentlyContinue | Out-Null
        Write-Host "  [OK] AutomatedLab LabSources location registered at $LabSourcesRoot" -ForegroundColor Green
    } else {
        Write-Warning "AutomatedLab is not installed; install it first to register LabSources."
    }
}

Write-Host "[OK] Storage subsystem initialized ($storageFs)." -ForegroundColor Green
