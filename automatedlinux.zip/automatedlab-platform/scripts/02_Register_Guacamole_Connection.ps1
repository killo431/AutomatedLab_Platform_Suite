function Add-GuacamoleConnection {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$GuacamoleUrl = "http://localhost:8443/guacamole",

        [Parameter(Mandatory = $true)]
        [string]$AdminUser = "guacadmin",

        [Parameter(Mandatory = $true)]
        [string]$AdminPassword = "guacadmin",

        [Parameter(Mandatory = $true)]
        [string]$ConnectionName,

        [Parameter(Mandatory = $true)]
        [string]$HostnameOrIp,

        [Parameter(Mandatory = $true)]
        [ValidateSet("rdp", "ssh")]
        [string]$Protocol,

        [Parameter(Mandatory = $false)]
        [string]$Username,

        [Parameter(Mandatory = $false)]
        [string]$Password
    )

    $AuthBody = @{
        username = $AdminUser
        password = $AdminPassword
    }
    $TokenResponse = Invoke-RestMethod -Uri "$GuacamoleUrl/api/tokens" -Method Post -Body $AuthBody
    $AuthToken = $TokenResponse.authToken
    $DataSource = $TokenResponse.dataSource

    $Parameters = @{
        "hostname" = $HostnameOrIp
        "port"     = if ($Protocol -eq "rdp") { "3389" } else { "22" }
        "ignore-cert" = "true"
    }

    if ($Protocol -eq "rdp") {
        $Parameters["security"] = "any"
        $Parameters["resize-method"] = "display-update"
        $Parameters["enable-drive"] = "true"
        $Parameters["drive-path"] = "/tmp/guac-share"
        if ($Username) { $Parameters["username"] = $Username }
        if ($Password) { $Parameters["password"] = $Password }
    } elseif ($Protocol -eq "ssh") {
        if ($Username) { $Parameters["username"] = $Username }
        if ($Password) { $Parameters["password"] = $Password }
    }

    $ConnectionPayload = @{
        name       = $ConnectionName
        protocol   = $Protocol
        parameters = $Parameters
    } | ConvertTo-Json -Depth 5

    $Headers = @{ "Guacamole-Token" = $AuthToken }
    $NewConn = Invoke-RestMethod -Uri "$GuacamoleUrl/api/session/data/$DataSource/connections" `
                                 -Method Post `
                                 -Headers $Headers `
                                 -ContentType "application/json" `
                                 -Body $ConnectionPayload

    Write-Host "[+] Registered Guacamole Connection '$ConnectionName' with ID $($NewConn.identifier)" -ForegroundColor Green

    return "$GuacamoleUrl/#/client/$( [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("$($NewConn.identifier)`0c`0$DataSource")) )?token=$AuthToken"
}

function Register-LabGuacamoleConnections {
    <#
    .SYNOPSIS
        Registers every VM in an AutomatedLab lab as a Guacamole connection.
    .EXAMPLE
        Register-LabGuacamoleConnections -LabName GettingStarted -GuacamoleUrl http://localhost:8443/guacamole
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$LabName,

        [Parameter(Mandatory = $false)]
        [string]$GuacamoleUrl = "http://localhost:8443/guacamole",

        [Parameter(Mandatory = $false)]
        [string]$AdminUser = "guacadmin",

        [Parameter(Mandatory = $false)]
        [string]$AdminPassword = "guacadmin"
    )

    Import-Module AutomatedLab -ErrorAction Stop
    Import-Lab -Name $LabName -ErrorAction Stop

    $vms = Get-LabVM
    foreach ($vm in $vms) {
        $name = $vm.Name
        $ip = $vm.IpAddress
        if (-not $ip -and $vm.IPAddress) { $ip = $vm.IPAddress }
        if (-not $ip) { $ip = $vm.HostName }

        $isLinux = $false
        if ($vm.OperatingSystem) {
            $isLinux = ($vm.OperatingSystem -match 'Linux|Ubuntu|CentOS|Debian|RedHat')
        }
        $protocol = if ($isLinux) { 'ssh' } else { 'rdp' }

        try {
            Add-GuacamoleConnection -GuacamoleUrl $GuacamoleUrl -AdminUser $AdminUser -AdminPassword $AdminPassword `
                -ConnectionName "$LabName - $name" -HostnameOrIp $ip -Protocol $protocol `
                -Username (if ($isLinux) { 'root' } else { 'Administrator' })
            Write-Host "[OK] Registered Guacamole connection for '$name' ($protocol -> $ip)." -ForegroundColor Green
        } catch {
            Write-Warning "Failed to register '$name': $_"
        }
    }
}
