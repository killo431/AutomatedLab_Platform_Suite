<#
.SYNOPSIS
    Custom Service and Application Delivery Engine for AutomatedLab and PowerShell Universal.
.DESCRIPTION
    Handles multi-part package ingestion, SHA256 integrity validation, staging to ReFS LabSources,
    and automated silent deployment into guest VMs via PowerShell Direct (VMBus) or WinRM.
#>

[CmdletBinding()]
param()

# 1. PowerShell Universal REST Upload Handler Endpoint
# Register in PowerShell Universal: Endpoints -> Add Endpoint
$UploadEndpointDefinition = @{
    Url        = "/api/v1/apps/upload"
    Method     = "POST"
    Description = "Ingests custom application binaries and generates package manifests"
    Script     = {
        param($Request)

        $TargetDirectory = "V:\LabSources\CustomUploads"
        if (-not (Test-Path $TargetDirectory)) {
            New-Item -Path $TargetDirectory -ItemType Directory -Force | Out-Null
        }

        # Extract file metadata from HTTP request headers
        $FileName = $Request.Headers["X-Package-Name"]
        if (-not $FileName) {
            $FileName = "UploadedPackage_$((Get-Date).ToString('yyyyMMdd_HHmmss')).bin"
        }

        $DestinationFile = Join-Path $TargetDirectory $FileName

        # Write binary content directly to storage
        [System.IO.File]::WriteAllBytes($DestinationFile, $Request.Body)

        # Compute SHA256 checksum for integrity assurance
        $CryptoHash = (Get-FileHash -Path $DestinationFile -Algorithm SHA256).Hash

        # Generate manifest descriptor
        $Manifest = [ordered]@{
            PackageName        = $FileName
            StagedPath         = $DestinationFile
            SHA256             = $CryptoHash
            UploadedAt         = (Get-Date).ToString("o")
            SizeInBytes        = (Get-Item $DestinationFile).Length
            DefaultSilentFlags = switch ([System.IO.Path]::GetExtension($FileName).ToLower()) {
                ".msi" { "/qn /norestart ALLUSERS=1" }
                ".exe" { "/S /quiet /norestart" }
                ".zip" { "Expand-Archive" }
                ".ps1" { "-ExecutionPolicy Bypass -NoProfile" }
                Default { "/quiet" }
            }
        }

        $ManifestPath = "$DestinationFile.manifest.json"
        $Manifest | ConvertTo-Json -Depth 4 | Set-Content -Path $ManifestPath -Encoding UTF8

        # Return status response
        @{
            Status   = "Success"
            Package  = $Manifest
            Message  = "Artifact successfully ingested into LabSources."
        } | ConvertTo-Json
    }
}

# 2. AutomatedLab In-Guest Deployment Engine
function Install-CustomLabService {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$LabName,

        [Parameter(Mandatory = $true)]
        [string]$TargetComputerName,

        [Parameter(Mandatory = $true)]
        [string]$PackageFileName,

        [Parameter(Mandatory = $false)]
        [string]$CustomArguments,

        [Parameter(Mandatory = $false)]
        [ValidateSet("MSI", "EXE", "Archive", "Script")]
        [string]$InstallerType
    )

    Write-Host "[-] Connecting to AutomatedLab environment: $LabName" -ForegroundColor Cyan
    Import-Lab -Name $LabName -ErrorAction Stop

    $SourceFilePath = "V:\LabSources\CustomUploads\$PackageFileName"
    if (-not (Test-Path $SourceFilePath)) {
        throw "Source binary package not found at: $SourceFilePath"
    }

    # Auto-detect installer type if omitted
    if (-not $InstallerType) {
        $Ext = [System.IO.Path]::GetExtension($PackageFileName).ToLower()
        $InstallerType = switch ($Ext) {
            ".msi" { "MSI" }
            ".exe" { "EXE" }
            ".zip" { "Archive" }
            ".ps1" { "Script" }
            Default { "EXE" }
        }
    }

    Write-Host "[-] Staging '$PackageFileName' to '$TargetComputerName' via VMBus / PowerShell Direct..." -ForegroundColor Cyan
    $GuestStagingDir = "C:\LabStaging"
    
    # Copy file to guest VM using AutomatedLab native transfer
    Copy-LabFileFilter -Path $SourceFilePath -DestinationPath $GuestStagingDir -ComputerName $TargetComputerName

    Write-Host "[-] Executing silent guest installation ($InstallerType)..." -ForegroundColor Cyan
    
    $GuestScriptBlock = {
        param($PkgName, $StagingDir, $Type, $UserArgs)

        $LocalFilePath = Join-Path $StagingDir $PkgName
        if (-not (Test-Path $LocalFilePath)) {
            throw "Staged package not found in guest at $LocalFilePath"
        }

        switch ($Type) {
            "MSI" {
                $ArgsList = if ($UserArgs) { "/i `"$LocalFilePath`" $UserArgs" } else { "/i `"$LocalFilePath`" /qn /norestart ALLUSERS=1" }
                $Process = Start-Process -FilePath "msiexec.exe" -ArgumentList $ArgsList -Wait -PassThru
                if ($Process.ExitCode -notin @(0, 3010)) {
                    throw "MSI execution failed with exit code: $($Process.ExitCode)"
                }
            }
            "EXE" {
                $ArgsList = if ($UserArgs) { $UserArgs } else { "/S /quiet /norestart" }
                $Process = Start-Process -FilePath $LocalFilePath -ArgumentList $ArgsList -Wait -PassThru
                if ($Process.ExitCode -notin @(0, 3010)) {
                    throw "EXE execution failed with exit code: $($Process.ExitCode)"
                }
            }
            "Archive" {
                $ExtractDir = "C:\Services\$([System.IO.Path]::GetFileNameWithoutExtension($PkgName))"
                Expand-Archive -Path $LocalFilePath -DestinationPath $ExtractDir -Force
            }
            "Script" {
                & powershell.exe -ExecutionPolicy Bypass -NoProfile -File $LocalFilePath
            }
        }
    }

    Invoke-LabCommand -ComputerName $TargetComputerName `
                      -ScriptBlock $GuestScriptBlock `
                      -ArgumentList $PackageFileName, $GuestStagingDir, $InstallerType, $CustomArguments `
                      -ErrorAction Stop

    Write-Host "[OK] Custom application '$PackageFileName' successfully installed on '$TargetComputerName'." -ForegroundColor Green
}
