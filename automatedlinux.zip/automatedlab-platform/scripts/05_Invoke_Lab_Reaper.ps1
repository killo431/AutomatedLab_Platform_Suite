<#
.SYNOPSIS
    Automated TTL Reaper and Orphan VM Sweeper for AutomatedLab.
.DESCRIPTION
    Reads LabRegistry.json (written by 06_Register_Lab_Lease.ps1) and tears down labs whose lease
    has expired. Use -InstallSchedule to register a scheduled task that runs the reaper hourly.
.PARAMETER RegistryPath
    Path to LabRegistry.json (default V:\LabSources\LabRegistry.json).
.PARAMETER DefaultLeaseHours
    Fallback lease duration for records that lack one (default 8).
.PARAMETER InstallSchedule
    Register (or refresh) a scheduled task that runs this script hourly.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$RegistryPath = "V:\LabSources\LabRegistry.json",

    [Parameter(Mandatory = $false)]
    [int]$DefaultLeaseHours = 8,

    [Parameter(Mandatory = $false)]
    [switch]$InstallSchedule
)

if ($InstallSchedule) {
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`" -RegistryPath `"$RegistryPath`""
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration ([TimeSpan]::MaxValue)
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    Register-ScheduledTask -TaskName "AutomatedLabReaper" -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null
    Write-Host "[OK] Scheduled the AutomatedLab reaper to run hourly." -ForegroundColor Green
    return
}

Import-Module AutomatedLab -ErrorAction SilentlyContinue

if (-not (Test-Path $RegistryPath)) {
    Write-Host "[-] No active registry found at $RegistryPath." -ForegroundColor Yellow
    return
}

$Registry = @(Get-Content $RegistryPath | ConvertFrom-Json)
$Now = Get-Date

foreach ($Lab in $Registry) {
    $Expiry = [DateTime]$Lab.ExpiresAt
    if ($Now -gt $Expiry) {
        Write-Warning "Lab '$($Lab.LabName)' has expired ($Expiry). Commencing teardown..."
        try {
            Import-Lab -Name $Lab.LabName -ErrorAction Stop
            Remove-Lab -Confirm:$false -ErrorAction Stop
            Write-Host "[OK] Cleaned up lab '$($Lab.LabName)'." -ForegroundColor Green
        } catch {
            Write-Error "Failed to remove lab '$($Lab.LabName)': $_"
        }
    }
}
