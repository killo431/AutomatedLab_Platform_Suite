<#
.SYNOPSIS
    Registers (or updates) a lab TTL lease in the LabRegistry consumed by 05_Invoke_Lab_Reaper.
.DESCRIPTION
    Adds/updates a { LabName, LeaseHours, RegisteredAt, ExpiresAt } record in LabRegistry.json so
    the scheduled reaper knows when to tear the lab down. Idempotent: re-running updates the expiry.
.PARAMETER LabName
    Name of the AutomatedLab lab.
.PARAMETER LeaseHours
    Lease duration in hours (default 8).
.PARAMETER RegistryPath
    Path to LabRegistry.json (default V:\LabSources\LabRegistry.json).
.EXAMPLE
    .\06_Register_Lab_Lease.ps1 -LabName GettingStarted -LeaseHours 12
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$LabName,

    [Parameter(Mandatory = $false)]
    [int]$LeaseHours = 8,

    [Parameter(Mandatory = $false)]
    [string]$RegistryPath = "V:\LabSources\LabRegistry.json"
)

$registryDir = Split-Path $RegistryPath -Parent
if (-not (Test-Path $registryDir)) {
    New-Item -Path $registryDir -ItemType Directory -Force | Out-Null
}

$now = Get-Date
$expires = $now.AddHours($LeaseHours).ToString("o")

$records = @()
if (Test-Path $RegistryPath) {
    $records = @(Get-Content $RegistryPath -Raw | ConvertFrom-Json)
}

# Replace any existing record for this lab, then append the updated one.
$records = @($records | Where-Object { $_.LabName -ne $LabName })
$records += [PSCustomObject]@{
    LabName      = $LabName
    LeaseHours   = $LeaseHours
    RegisteredAt = $now.ToString("o")
    ExpiresAt    = $expires
}

$records | ConvertTo-Json -Depth 4 | Set-Content -Path $RegistryPath -Encoding UTF8
Write-Host "[OK] Registered lab '$LabName' with a $LeaseHours-hour lease (expires $expires)." -ForegroundColor Green
