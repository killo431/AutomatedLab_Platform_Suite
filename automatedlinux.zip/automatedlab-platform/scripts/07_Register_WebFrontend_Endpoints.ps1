<#
.SYNOPSIS
    Registers the REST endpoints used by the AUTOMATElab web dashboard.
.DESCRIPTION
    Registers two PowerShell Universal endpoints consumed by the AUTOMATElab landing page:
      GET /api/v1/automatelab/status  -> host status (Hyper-V, Docker, Guacamole, Studio URLs)
      GET /api/v1/automatelab/labs    -> list of labs with their lease expiry
    Run inside PowerShell Universal (or after Import-Module PowerShellUniversal).
#>

[CmdletBinding()]
param()

Import-Module PowerShellUniversal -ErrorAction SilentlyContinue
Import-Module AutomatedLab -ErrorAction SilentlyContinue

if (-not (Get-Command New-PSUEndpoint -ErrorAction SilentlyContinue)) {
    Write-Warning "New-PSUEndpoint is not available. Run this script inside PowerShell Universal."
    return
}

# Host status endpoint
New-PSUEndpoint -Url "/api/v1/automatelab/status" -Method "GET" -Endpoint {
    $hyperv = (Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue).HypervisorPresent
    $docker = [bool](Get-Command docker -ErrorAction SilentlyContinue)
    [PSCustomObject]@{
        host      = $env:COMPUTERNAME
        hyperv    = [bool]$hyperv
        docker    = $docker
        guacamole = "http://localhost:8443/guacamole"
        studio    = "/automatedlab"
    } | ConvertTo-Json
} | Out-Null

# Labs endpoint (merges AutomatedLab definitions with LabRegistry.json leases)
New-PSUEndpoint -Url "/api/v1/automatelab/labs" -Method "GET" -Endpoint {
    Import-Module AutomatedLab -ErrorAction SilentlyContinue
    $names = @()
    try { $names = @(Get-Lab -List -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name) } catch { }

    $registry = @()
    if (Test-Path "V:\LabSources\LabRegistry.json") {
        try { $registry = @(Get-Content "V:\LabSources\LabRegistry.json" -Raw | ConvertFrom-Json) } catch { }
    }

    $result = @()
    foreach ($name in $names) {
        $lease = $registry | Where-Object { $_.LabName -eq $name } | Select-Object -First 1
        $result += [PSCustomObject]@{
            name      = $name
            expiresAt = if ($lease) { $lease.ExpiresAt } else { $null }
        }
    }
    $result | ConvertTo-Json -Depth 3
} | Out-Null

Write-Host "[OK] Registered AUTOMATElab endpoints (/api/v1/automatelab/status, /api/v1/automatelab/labs)." -ForegroundColor Green
