<#
.SYNOPSIS
    AutomatedLab Platform go/no-go smoke test.
.DESCRIPTION
    Verifies the host is ready for deployment and reports a pass/fail summary.
    Exits 0 on success, 1 on any failure (suitable for CI / go-live gates).

    Checks:
      - Elevated session
      - PowerShell 7.4+
      - Hyper-V hypervisor active
      - AutomatedLab >= 5.58 (MSI)
      - Web frontend modules (AutomatedLab.Utils, Configuration, PSU app)
      - PowerShell Universal service running
      - Docker (Linux containers)
      - AUTOMATElab REST endpoint + /automatedlab Studio app
#>

[CmdletBinding()]
param()

$ErrorActionPreference = "Continue"
$script:results = @()

function Test-Item {
    param([string]$Name, [bool]$Pass, [string]$Detail = "")
    $script:results += [PSCustomObject]@{
        Check  = $Name
        Result = $(if ($Pass) { "PASS" } else { "FAIL" })
        Detail = $Detail
    }
    $tag  = $(if ($Pass) { "PASS" } else { "FAIL" })
    $color = $(if ($Pass) { "Green" } else { "Red" })
    Write-Host ("[{0}] {1}  {2}" -f $tag, $Name, $Detail) -ForegroundColor $color
}

Write-Host "====================================================================" -ForegroundColor Cyan
Write-Host " AUTOMATEDLAB PLATFORM SMOKE TEST" -ForegroundColor Cyan
Write-Host "====================================================================" -ForegroundColor Cyan

# 1. Elevated session
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
Test-Item "Elevated session" $isAdmin

# 2. PowerShell 7
$pwshVer = $null
$pwsh = Get-Command pwsh -ErrorAction SilentlyContinue
if ($pwsh) {
    try { $pwshVer = (& pwsh -NoProfile -Command '$PSVersionTable.PSVersion.ToString()').Trim() } catch { }
}
Test-Item "PowerShell 7.4+" ([bool]$pwshVer -and ([version]$pwshVer -ge [version]"7.4.0")) "$pwshVer"

# 3. Hyper-V
$hyperv = (Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue).HypervisorPresent
Test-Item "Hyper-V hypervisor" [bool]$hyperv

# 4. AutomatedLab >= 5.58 (MSI)
$al = Get-Module -ListAvailable -Name AutomatedLab | Sort-Object Version -Descending | Select-Object -First 1
Test-Item "AutomatedLab >= 5.58" ($al -and $al.Version -ge [version]"5.58.0") "$($al.Version)"

# 5. Web frontend modules
foreach ($m in @("AutomatedLab.Utils", "Configuration", "PowerShellUniversal.Apps.AutomatedLab", "PowerShellUniversal")) {
    $mod = Get-Module -ListAvailable -Name $m | Sort-Object Version -Descending | Select-Object -First 1
    Test-Item "Module $m" [bool]$mod "$($mod.Version)"
}

# 6. PowerShell Universal service
$psu = Get-Service -Name "PowerShellUniversal" -ErrorAction SilentlyContinue
Test-Item "PowerShell Universal service" ($psu -and $psu.Status -eq "Running") "$($psu.Status)"

# 7. Docker (Linux containers)
$dockerLinux = $false
if (Get-Command docker -ErrorAction SilentlyContinue) {
    try {
        $raw = docker info --format '{{.OSType}}' 2>$null
        $dockerLinux = ([string]$raw).Trim() -eq 'linux'
    } catch { }
}
Test-Item "Docker (Linux containers)" $dockerLinux

# 8. AUTOMATElab REST endpoint + Studio app
$base = "http://localhost:5000"
$status = $null
try { $status = Invoke-RestMethod -Uri "$base/api/v1/automatelab/status" -TimeoutSec 5 -ErrorAction Stop } catch { }
Test-Item "AUTOMATElab status endpoint" [bool]$status

$studio = $null
try { $studio = Invoke-WebRequest -Uri "$base/automatedlab" -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop } catch { }
Test-Item "AutomatedLab Studio (/automatedlab)" ($studio -and $studio.StatusCode -eq 200)

# Summary
$failed = @($script:results | Where-Object { $_.Result -eq "FAIL" })
Write-Host "`n====================================================================" -ForegroundColor Cyan
Write-Host (" RESULTS: {0}/{1} passed" -f ($script:results.Count - $failed.Count), $script:results.Count) -ForegroundColor $(if ($failed.Count -eq 0) { "Green" } else { "Red" })
if ($failed.Count -gt 0) {
    Write-Host " FAILED:" -ForegroundColor Red
    $failed | ForEach-Object { Write-Host ("   - {0}" -f $_.Check) -ForegroundColor Red }
}
Write-Host "====================================================================" -ForegroundColor Cyan

if ($failed.Count -gt 0) { exit 1 } else { exit 0 }
