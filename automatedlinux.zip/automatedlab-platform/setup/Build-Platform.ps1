<#
.SYNOPSIS
    Master bootstrap: install PowerShell 7 + all prerequisites, then run the full platform setup.
.DESCRIPTION
    Takes a clean Windows Server 2022/2025 (or Windows 11 Enterprise) host to a running
    AutomatedLab + PowerShell Universal + Apache Guacamole platform in one command.

    Phases (in order):
      1. Install-Prerequisites.ps1  -> NuGet, PowerShellGet, Git, Python, Docker, Keeper CLI
      2. Install-PowerShell7.ps1    -> PowerShell 7.4+ runtime
      3. Fast-Setup.ps1             -> Hyper-V, ReFS 64KB, AutomatedLab modules, PSU, Guacamole
      4. Verification report

.PARAMETER TargetDiskNumber
    Disk number of the fast NVMe disk to format with ReFS (default 1).
.PARAMETER StorageDriveLetter
    Drive letter assigned to the ReFS storage root (default V).
.PARAMETER SkipDiskFormat
    Skip ReFS formatting and use an existing directory root.
.PARAMETER DeployGuacamole
    Deploy the Guacamole HTML5 gateway via Docker Compose (default true).
.PARAMETER SkipPrerequisites
    Skip phase 1 (already-installed toolchain).
.PARAMETER SkipPowerShell7
    Skip phase 2 (already-installed PowerShell 7).
.PARAMETER SkipKeeperCommander
    Skip installing the Keeper Commander CLI during phase 1.
.EXAMPLE
    .\Build-Platform.ps1
.EXAMPLE
    .\Build-Platform.ps1 -TargetDiskNumber 2 -StorageDriveLetter S -SkipDiskFormat
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [int]$TargetDiskNumber = 1,

    [Parameter(Mandatory = $false)]
    [string]$StorageDriveLetter = "V",

    [Parameter(Mandatory = $false)]
    [switch]$SkipDiskFormat,

    [Parameter(Mandatory = $false)]
    [bool]$DeployGuacamole = $true,

    [Parameter(Mandatory = $false)]
    [switch]$SkipPrerequisites,

    [Parameter(Mandatory = $false)]
    [switch]$SkipPowerShell7,

    [Parameter(Mandatory = $false)]
    [switch]$SkipKeeperCommander
)

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Test-Admin {
    ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

Write-Host "====================================================================" -ForegroundColor Cyan
Write-Host " AUTOMATEDLAB PLATFORM - FULL ENVIRONMENT BUILD" -ForegroundColor Cyan
Write-Host "====================================================================" -ForegroundColor Cyan

if (-not (Test-Admin)) {
    throw "Build-Platform.ps1 must be run from an elevated Administrator PowerShell prompt."
}

Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope LocalMachine -Force

$setupRoot = $PSScriptRoot
$platformRoot = Split-Path $setupRoot -Parent

# ---- Phase 1: Toolchain prerequisites -----------------------------------
if (-not $SkipPrerequisites) {
    Write-Host "`n[Phase 1/4] Installing toolchain prerequisites..." -ForegroundColor Cyan
    $prereqParams = @{}
    if ($SkipKeeperCommander) { $prereqParams.SkipKeeperCommander = $true }
    & (Join-Path $setupRoot "Install-Prerequisites.ps1") @prereqParams
} else {
    Write-Host "`n[Phase 1/4] Skipped (prerequisites already installed)." -ForegroundColor DarkGray
}

# ---- Phase 2: PowerShell 7 runtime ---------------------------------------
if (-not $SkipPowerShell7) {
    Write-Host "`n[Phase 2/4] Installing PowerShell 7..." -ForegroundColor Cyan
    & (Join-Path $setupRoot "Install-PowerShell7.ps1")
} else {
    Write-Host "`n[Phase 2/4] Skipped (PowerShell 7 already installed)." -ForegroundColor DarkGray
}

# ---- Phase 3: Platform setup (Hyper-V, ReFS, modules, PSU, Guacamole) ----
Write-Host "`n[Phase 3/4] Running platform Fast-Setup..." -ForegroundColor Cyan
$fastSetup = Join-Path $platformRoot "Fast-Setup.ps1"
if (-not (Test-Path $fastSetup)) {
    throw "Fast-Setup.ps1 not found at expected location: $fastSetup"
}

$fastParams = @{
    TargetDiskNumber   = $TargetDiskNumber
    StorageDriveLetter = $StorageDriveLetter
    DeployGuacamole    = $DeployGuacamole
}
if ($SkipDiskFormat) { $fastParams.SkipDiskFormat = $true }

& $fastSetup @fastParams

# ---- Phase 4: Verification report ----------------------------------------
Write-Host "`n[Phase 4/4] Verification report..." -ForegroundColor Cyan

Write-Host "  PowerShell 7 :" -NoNewline
$pwsh = Get-Command pwsh -ErrorAction SilentlyContinue
if ($pwsh) { Write-Host " $(& pwsh -NoProfile -Command '$PSVersionTable.PSVersion')" -ForegroundColor Green } else { Write-Host " not found" -ForegroundColor Red }

Write-Host "  Docker        :" -NoNewline
$docker = Get-Command docker -ErrorAction SilentlyContinue
if ($docker) { Write-Host " $(docker --version)" -ForegroundColor Green } else { Write-Host " not found (Guacamole phase will be skipped)" -ForegroundColor Yellow }

Write-Host "  Python        :" -NoNewline
$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) { Write-Host " $(python --version)" -ForegroundColor Green } else { Write-Host " not found" -ForegroundColor Yellow }

Write-Host "  AutomatedLab modules:" -ForegroundColor Cyan
foreach ($mod in @("AutomatedLab", "AutomatedLab.Common", "AutomatedLab.Core", "AutomatedLab.Definition", "AutomatedLab.Worker", "PowerShellUniversal")) {
    $m = Get-Module -ListAvailable -Name $mod | Sort-Object Version -Descending | Select-Object -First 1
    if ($m) { Write-Host "    [OK] $mod $($m.Version)" -ForegroundColor Green } else { Write-Host "    [--] $mod NOT installed" -ForegroundColor Red }
}

$psu = Get-Service -Name "PowerShellUniversal" -ErrorAction SilentlyContinue
if ($psu) { Write-Host "  PSU service   : $($psu.Status)" -ForegroundColor Green } else { Write-Host "  PSU service   : not registered" -ForegroundColor Yellow }

Write-Host "`n====================================================================" -ForegroundColor Green
Write-Host " ENVIRONMENT BUILD COMPLETE" -ForegroundColor Green
Write-Host "====================================================================" -ForegroundColor Green
Write-Host " If Hyper-V, Containers, or Docker features were just enabled," -ForegroundColor Yellow
Write-Host " REBOOT the host, then re-run this script to finish the setup." -ForegroundColor Yellow
