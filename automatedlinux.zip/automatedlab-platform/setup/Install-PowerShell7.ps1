<#
.SYNOPSIS
    Installs or upgrades PowerShell 7 (pwsh) on Windows Server 2022/2025 or Windows 11.
.DESCRIPTION
    PowerShell Universal 5.x background workers require PowerShell 7.4+. This script
    installs PowerShell 7 via winget when available and falls back to the official
    GitHub release MSI. Idempotent: exits cleanly when a suitable version is present.
.PARAMETER Version
    Pin a specific PowerShell version, e.g. "7.4.6". Defaults to the latest stable release.
.PARAMETER Force
    Reinstall even when PowerShell 7.4+ is already present.
.EXAMPLE
    .\Install-PowerShell7.ps1
.EXAMPLE
    .\Install-PowerShell7.ps1 -Version 7.4.6 -Force
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$Version,

    [Parameter(Mandatory = $false)]
    [switch]$Force
)

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Test-Admin {
    ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-PwshVersion {
    $cmd = Get-Command pwsh -ErrorAction SilentlyContinue
    if (-not $cmd) { return $null }
    try {
        $ver = & pwsh -NoProfile -Command '$PSVersionTable.PSVersion.ToString()'
        return $ver.Trim()
    } catch {
        return $null
    }
}

if (-not (Test-Admin)) {
    throw "Install-PowerShell7.ps1 must be run from an elevated Administrator PowerShell prompt."
}

$current = Get-PwshVersion
Write-Host "[-] Detected PowerShell 7: $(if ($current) { $current } else { '<not installed>' })" -ForegroundColor Yellow

if ($current -and -not $Force) {
    try {
        $currentVer = [version]($current -replace '[^0-9.]', '')
        if ($currentVer -ge [version]"7.4.0") {
            Write-Host "  [OK] PowerShell 7.4+ already installed. Use -Force to reinstall." -ForegroundColor Green
            return
        }
    } catch { }
}

# 1. Preferred: winget
$winget = Get-Command winget -ErrorAction SilentlyContinue
if ($winget) {
    Write-Host "[-] Installing PowerShell 7 via winget..." -ForegroundColor Yellow
    try {
        $wArgs = @("install", "--id", "Microsoft.PowerShell", "--source", "winget", "--silent", "--accept-package-agreements", "--accept-source-agreements")
        if ($Version) { $wArgs += @("--version", $Version) }
        & winget @wArgs
        if ($LASTEXITCODE -eq 0) {
            $after = Get-PwshVersion
            Write-Host "  [OK] Installed PowerShell $after" -ForegroundColor Green
            return
        }
    } catch {
        Write-Warning "winget install failed: $_"
    }
}

# 2. Fallback: official GitHub release MSI
Write-Host "[-] Falling back to official GitHub release MSI..." -ForegroundColor Yellow
$arch = if ([Environment]::Is64BitOperatingSystem) { "win-x64" } else { "win-x86" }

$releaseUrl = if ($Version) {
    "https://api.github.com/repos/PowerShell/PowerShell/releases/tags/v$Version"
} else {
    "https://api.github.com/repos/PowerShell/PowerShell/releases/latest"
}

$release = Invoke-RestMethod -Uri $releaseUrl -Headers @{ "User-Agent" = "AutomatedLab-Setup" }
$asset = $release.assets | Where-Object { $_.name -like "PowerShell-*-$arch.msi" } | Select-Object -First 1
if (-not $asset) {
    throw "No PowerShell MSI asset found for architecture '$arch' in release '$($release.tag_name)'."
}

$msi = Join-Path $env:TEMP $asset.name
Write-Host "[-] Downloading $($asset.name)..." -ForegroundColor Yellow
Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $msi -UseBasicParsing

Write-Host "[-] Installing PowerShell 7 MSI (silent)..." -ForegroundColor Yellow
$p = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$msi`" /qn /norestart ADD_PATH=1 ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=1 ENABLE_PSREMOTING=1 REGISTER_MANIFEST=1" -Wait -PassThru
if ($p.ExitCode -notin @(0, 3010)) {
    throw "PowerShell 7 MSI install failed with exit code $($p.ExitCode)."
}

$after = Get-PwshVersion
Write-Host "  [OK] Installed PowerShell $after" -ForegroundColor Green
if ($p.ExitCode -eq 3010) {
    Write-Warning "A reboot is required to complete the PowerShell 7 installation."
}
