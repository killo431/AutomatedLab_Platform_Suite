<#
.SYNOPSIS
    Installs host toolchain prerequisites for the AutomatedLab Platform.
.DESCRIPTION
    Bootstraps the non-PowerShell dependencies required to build/run the platform:
      - NuGet package provider + PowerShellGet + PSResourceGet
      - Git
      - Python 3.12 (and pip)
      - Docker Engine (Windows Server) or Docker Desktop (Windows 11)
      - Keeper Commander CLI (pip)
    Every step is idempotent and skippable via switch parameters.
.PARAMETER SkipGit
    Do not install Git.
.PARAMETER SkipPython
    Do not install Python 3.
.PARAMETER SkipDocker
    Do not install Docker.
.PARAMETER SkipKeeperCommander
    Do not install the Keeper Commander CLI.
.EXAMPLE
    .\Install-Prerequisites.ps1
.EXAMPLE
    .\Install-Prerequisites.ps1 -SkipDocker -SkipKeeperCommander
#>

[CmdletBinding()]
param(
    [switch]$SkipGit,
    [switch]$SkipPython,
    [switch]$SkipDocker,
    [switch]$SkipKeeperCommander
)

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Test-Admin {
    ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-WindowsServer {
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    return ($os -and $os.ProductType -eq 3)
}

function Ensure-Winget {
    if (Get-Command winget -ErrorAction SilentlyContinue) { return $true }
    Write-Host "  [+] winget not found; attempting to install App Installer..." -ForegroundColor Cyan
    try {
        $vclibs = Join-Path $env:TEMP "Microsoft.VCLibs.x64.14.00.Desktop.appx"
        $installer = Join-Path $env:TEMP "Microsoft.DesktopAppInstaller.msixbundle"
        Invoke-WebRequest "https://aka.ms/Microsoft.VCLibs.x64.14.00.Desktop.appx" -OutFile $vclibs -UseBasicParsing
        Invoke-WebRequest "https://github.com/microsoft/winget-cli/releases/latest/download/Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.msixbundle" -OutFile $installer -UseBasicParsing
        Add-AppxPackage -Path $vclibs
        Add-AppxPackage -Path $installer
        return [bool](Get-Command winget -ErrorAction SilentlyContinue)
    } catch {
        Write-Warning "Could not auto-install winget: $_"
        return $false
    }
}

if (-not (Test-Admin)) {
    throw "Install-Prerequisites.ps1 must be run from an elevated Administrator PowerShell prompt."
}

# 1. NuGet package provider
Write-Host "[-] Ensuring NuGet package provider..." -ForegroundColor Yellow
if (-not (Get-PackageProvider -Name NuGet -ListAvailable -ErrorAction SilentlyContinue)) {
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force | Out-Null
    Write-Host "  [OK] NuGet installed." -ForegroundColor Green
} else {
    Write-Host "  [OK] NuGet already present." -ForegroundColor Green
}

# 2. PowerShellGet + PSResourceGet
Write-Host "[-] Updating PowerShellGet..." -ForegroundColor Yellow
Install-Module -Name PowerShellGet -Scope AllUsers -Force -AllowClobber -SkipPublisherCheck -ErrorAction SilentlyContinue | Out-Null
Write-Host "[-] Installing PSResourceGet (modern module cmdlets)..." -ForegroundColor Yellow
Install-Module -Name Microsoft.PowerShell.PSResourceGet -Scope AllUsers -Force -AllowClobber -ErrorAction SilentlyContinue | Out-Null
Write-Host "  [OK] PowerShell module providers ready." -ForegroundColor Green

$haveWinget = Ensure-Winget

# 3. Git
if (-not $SkipGit) {
    Write-Host "[-] Ensuring Git..." -ForegroundColor Yellow
    if (Get-Command git -ErrorAction SilentlyContinue) {
        Write-Host "  [OK] Git already installed." -ForegroundColor Green
    } elseif ($haveWinget) {
        winget install --id Git.Git --source winget --silent --accept-package-agreements --accept-source-agreements
        Write-Host "  [OK] Git installed." -ForegroundColor Green
    } else {
        Write-Warning "Git not installed and winget unavailable. Install manually from https://git-scm.com/download/win"
    }
}

# 4. Python 3
if (-not $SkipPython) {
    Write-Host "[-] Ensuring Python 3..." -ForegroundColor Yellow
    if (Get-Command python -ErrorAction SilentlyContinue) {
        Write-Host "  [OK] Python already installed." -ForegroundColor Green
    } else {
        $installed = $false
        if ($haveWinget) {
            winget install --id Python.Python.3.12 --source winget --silent --accept-package-agreements --accept-source-agreements
            if ($LASTEXITCODE -eq 0) { $installed = $true }
        }
        if (-not $installed) {
            Write-Host "  [+] winget path failed/unavailable; downloading Python from python.org..." -ForegroundColor Cyan
            $pyInstaller = Join-Path $env:TEMP "python-3.12.9-amd64.exe"
            Invoke-WebRequest "https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe" -OutFile $pyInstaller -UseBasicParsing
            Start-Process -FilePath $pyInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_pip=1" -Wait
            $installed = $true
        }
        Write-Host "  [OK] Python installed." -ForegroundColor Green
    }

    # Refresh PATH in this session so pip/py are resolvable immediately.
    $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
    if (Get-Command python -ErrorAction SilentlyContinue) {
        python -m pip install --upgrade pip | Out-Null
        Write-Host "  [OK] pip upgraded." -ForegroundColor Green
    }
}

# 5. Docker
if (-not $SkipDocker) {
    Write-Host "[-] Ensuring Docker..." -ForegroundColor Yellow
    if (Get-Command docker -ErrorAction SilentlyContinue) {
        Write-Host "  [OK] Docker already installed." -ForegroundColor Green
    } elseif (Test-WindowsServer) {
        Write-Host "  [+] Windows Server detected: installing Docker Engine (Windows containers)..." -ForegroundColor Cyan

        $feature = Get-WindowsOptionalFeature -Online -FeatureName Containers -ErrorAction SilentlyContinue
        if ($feature -and $feature.State -ne "Enabled") {
            Enable-WindowsOptionalFeature -Online -FeatureName Containers -NoRestart -All | Out-Null
        }

        $dockerScript = Join-Path $env:TEMP "install-docker-ce.ps1"
        Invoke-WebRequest "https://raw.githubusercontent.com/microsoft/Windows-Containers/Main/helpful_tools/Install-DockerCE/install-docker-ce.ps1" -OutFile $dockerScript -UseBasicParsing
        & $dockerScript

        # Ensure Docker Compose v2 plugin is present.
        $composeDir = Join-Path $env:ProgramFiles "Docker\cli-plugins"
        $composeExe = Join-Path $composeDir "docker-compose.exe"
        if (-not (Test-Path $composeExe)) {
            Write-Host "  [+] Installing Docker Compose v2 plugin..." -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $composeDir -Force | Out-Null
            Invoke-WebRequest "https://github.com/docker/compose/releases/latest/download/docker-compose-windows-x86_64.exe" -OutFile $composeExe -UseBasicParsing
        }
        Write-Host "  [OK] Docker Engine installed. A reboot may be required before 'docker' is usable." -ForegroundColor Green
    } elseif ($haveWinget) {
        Write-Host "  [+] Client OS detected: installing Docker Desktop (WSL2 backend)..." -ForegroundColor Cyan
        winget install --id Docker.DockerDesktop --source winget --silent --accept-package-agreements --accept-source-agreements
        Write-Host "  [OK] Docker Desktop installed. A reboot/logout is required." -ForegroundColor Green
    } else {
        Write-Warning "Docker not installed and winget unavailable. Install Docker Desktop from https://docs.docker.com/desktop/"
    }
}

# 6. Keeper Commander CLI
if (-not $SkipKeeperCommander) {
    Write-Host "[-] Ensuring Keeper Commander CLI..." -ForegroundColor Yellow
    if (Get-Command python -ErrorAction SilentlyContinue) {
        python -m pip install --upgrade keepercommander | Out-Null
        Write-Host "  [OK] Keeper Commander installed (invoke as 'keeper')." -ForegroundColor Green
    } else {
        Write-Warning "Python not available; skipping Keeper Commander. Re-run after installing Python."
    }
}

Write-Host "`n[OK] Prerequisites phase complete." -ForegroundColor Green
