---
name: eraser-diagrams
description: Generate architecture and flow diagrams as text using Eraser diagram-as-code syntax.
---

# Eraser Diagram-as-Code

Produce clear architecture/flow diagrams as version-controllable text.

## References

- **Open-source system (JSON):** https://github.com/eraserlabs/eraser-diagrams
  - `@eraserlabs/diagrams` (Node API) and `eraser-diagrams` (CLI).
- **Classic Eraser DSL:** https://docs.eraser.io/architecture-diagram-syntax

## Classic DSL (preferred for text artifacts)

```
// Node
compute [icon: aws-ec2]

// Group / containment
Cloud [icon: aws] {
  compute [icon: aws-ec2]
  database [icon: aws-rds]
}

// Connection (optionally labeled)
compute -> database: "writes to"
```

- Node names are required; properties go in `[ ]`.
- Use `{ }` for containment/grouping.
- Use `->` for directed connections; add `: "label"` for the edge label.
- Common icons: `aws-ec2`, `aws-rds`, `aws-s3`, `server`, `database`, `user`, `web`, `api`, `code`, `lock`, `docker`, `kubernetes`.

## When to use which

- **Classic DSL** — quick, portable, low-token diagrams checked into docs.
- **JSON system** — programmatic/CI generation with full layout control (`@eraserlabs/diagrams`).

## Example (AutomatedLab platform)

See `docs/diagrams/automatedlab-platform.eraser`.
