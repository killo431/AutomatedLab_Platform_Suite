# OpenTofu Provisioning Engine

Compiles the no-code VisualTopology JSON into **OpenTofu/Terraform HCL** and applies it.

## Backends

| Provider | What it deploys | Provider registry |
| :--- | :--- | :--- |
| `docker` | Container labs (PostgreSQL, Redis, NGINX) + bridge networks | `kreuzwerker/docker` |
| `proxmox` | VM labs cloned from a driver-neutral base image | `bpg/proxmox` |

## Usage

```bash
cd automatedlab-platform/tofu
chmod +x *.sh

# Container labs (Docker)
python3 graph_to_hcl.py --input examples/sample-graph.json --provider docker --outdir out
./apply.sh out

# VM labs (Proxmox)
python3 graph_to_hcl.py --input examples/sample-graph.json --provider proxmox --outdir out
# set TF_VAR_* or a .tfvars before apply
./apply.sh out
```

For Proxmox, provide credentials (see `variables.tf`):
```bash
export TF_VAR_proxmox_endpoint="https://pve:8006/"
export TF_VAR_proxmox_username="root@pam"
export TF_VAR_proxmox_password="..."
export TF_VAR_proxmox_node="pve"
export TF_VAR_base_vm_id=9000
```

## Graph schema

The compiler consumes the spec's `VisualTopology` JSON (`labName`, `addressSpace`, `nodes`, `edges`):

- `vSwitchNode` → `docker_network` / Proxmox bridge
- `containerNode` → `docker_container` (services: postgres/redis/nginx)
- `vmNode` → `proxmox_virtual_environment_vm` (clones `base_vm_id`)

## Notes / caveats

- The Proxmox resource syntax (`proxmox_virtual_environment_vm`) is a template — verify field
  names against your installed `bpg/proxmox` version; it evolves quickly.
- **Hyper-V is not an OpenTofu backend** (no first-class provider). The same *driver-neutral base
  image* is what makes VMs portable: deploy to Proxmox via OpenTofu, or to Hyper-V via the
  Windows `Fast-Setup.ps1`/AutomatedLab path — same base disk, no per-VM conversion.

See **[base-images.md](base-images.md)** for the driver-neutral image strategy.
