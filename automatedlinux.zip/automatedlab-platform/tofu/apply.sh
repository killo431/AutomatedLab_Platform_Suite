#!/usr/bin/env bash
set -euo pipefail
# OpenTofu apply wrapper. Usage: ./apply.sh [outdir]
OUTDIR="${1:-./out}"
cd "$OUTDIR"
tofu init
tofu plan
tofu apply -auto-approve
