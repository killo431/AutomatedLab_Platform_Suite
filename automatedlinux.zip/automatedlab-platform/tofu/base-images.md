# Driver-Neutral Base Images

The key to "move Proxmox ↔ Hyper-V by re-running `tofu apply`" is a **single base disk image that
boots on both hypervisors**. Build it once, clone it everywhere — no per-VM conversion.

## Linux base image (easy)

Linux kernels ship drivers for both **virtio (KVM/Proxmox)** and **Hyper-V synthetic** devices, so a
standard cloud image is already portable.

```bash
# Ubuntu 24.04 cloud image (KVM-ready, generic drivers)
wget https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img

# Import as a Proxmox template (VM ID 9000) with cloud-init
qm create 9000 --name base-ubuntu-2404 --memory 4096 --cores 2 --net0 virtio,bridge=vmbr0
qm importdisk 9000 noble-server-cloudimg-amd64.img local-lvm
qm set 9000 --scsihw virtio-scsi-pci --scsi0 local-lvm:vm-9000-disk-0
qm set 9000 --ide2 local-lvm:cloudinit
qm set 9000 --boot c --bootdisk scsi0
qm set 9000 --serial0 socket --vga serial0
qm set 9000 --agent 1
qm template 9000
```

To use the same image on Hyper-V, convert once with `qemu-img`:

```bash
qemu-img convert -f raw -O vhdx noble-server-cloudimg-amd64.img base-ubuntu-2404.vhdx
```

## Windows base image (the important one)

Windows needs **both** driver sets preinstalled so it boots on either hypervisor:

1. Install Windows in a VM (on either hypervisor) with a **standard SATA/SCSI** controller (not virtio).
2. Install **virtio-win** drivers (netkvm, viostor, viorng, qxl):
   - https://fedorapeople.org/groups/virt/virtio-win/direct-downloads/
3. Install **Hyper-V Integration Services** (built into modern Windows; enable the Hyper-V guest
   components + `hv_*` synthetic drivers).
4. Enable both NIC/disk driver stacks so Windows can fall back to whichever is present.
5. Run `sysprep /generalize /oobe /shutdown`, then convert the disk into a template on each hypervisor.

### Import to Proxmox

```bash
qm create 9001 --name base-windows-2022 --memory 4096 --cores 2 --net0 e1000,bridge=vmbr0
qm importdisk 9001 windows-2022-base.qcow2 local-lvm
qm set 9001 --scsihw virtio-scsi-pci --scsi0 local-lvm:vm-9001-disk-0
qm template 9001
```

### Convert for Hyper-V

```bash
qemu-img convert -f qcow2 -O vhdx windows-2022-base.qcow2 base-windows-2022.vhdx
# then: New-VM (Gen2/UEFI), attach the VHDX
```

## Result

- Proxmox lab → OpenTofu (`bpg/proxmox`) clones `base_vm_id`.
- Hyper-V lab → Windows `Fast-Setup.ps1`/AutomatedLab clones the same VHDX.

Same base disk, two hypervisors, no conversion at deploy time.
