#!/usr/bin/env bash
set -euo pipefail
# OpenTofu destroy wrapper. Usage: ./destroy.sh [outdir]
OUTDIR="${1:-./out}"
cd "$OUTDIR"
tofu destroy -auto-approve
