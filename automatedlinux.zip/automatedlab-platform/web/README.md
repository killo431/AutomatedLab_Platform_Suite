# AUTOMATElab Studio — No-Code Canvas (M1)

React 18 + Vite + TypeScript + React Flow (`@xyflow/react`) + Tailwind CSS + Zustand.

## Status: M1 (Core Canvas Scaffolding)

M1 acceptance criteria (from the spec):
- React Flow canvas with pan/zoom and custom node components (`vmNode`, `vSwitchNode`, `containerNode`).
- Drag-and-drop from the palette onto the canvas; nodes render and can be connected.

## Structure

```
web/
├── package.json
├── vite.config.ts          # dev proxy: /api -> http://localhost:5000 (PSU)
├── tsconfig.json
├── tsconfig.node.json
├── tailwind.config.js
├── postcss.config.js
└── src/
    ├── main.tsx
    ├── App.tsx             # header + palette + canvas shell
    ├── index.css
    ├── types.ts            # LabNodeData / NodeKind graph schema
    ├── store.ts            # Zustand store (nodes/edges, add/connect)
    └── components/
        ├── Palette.tsx     # draggable node palette
        ├── Canvas.tsx      # React Flow canvas + drop handling
        └── nodes/          # vmNode, vSwitchNode, containerNode
```

## Run

```bash
cd web
npm install
npm run dev      # http://localhost:5173 (API proxied to PSU :5000)
npm run build    # production build -> dist/
```

## Graph schema

The node graph mirrors the spec's `VisualTopology` JSON schema:
- `vmNode` — OS, RAM, vCPU, IP, roles.
- `vSwitchNode` — network address space.
- `containerNode` — service list (postgres, redis, nginx).

## Next milestones (M2–M5)

- **M2:** property inspector + relationship validation.
- **M3:** graph-to-PowerShell compiler + PSU `/api/v1/labs/deploy` binding.
- **M4:** WebSocket telemetry + Guacamole console modal.
- **M5:** AI copilot + 1-click Keeper export.
