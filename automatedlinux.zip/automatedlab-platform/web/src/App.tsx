import { ReactFlowProvider } from '@xyflow/react'
import Palette from './components/Palette'
import Canvas from './components/Canvas'

export default function App() {
  return (
    <div className="flex h-screen flex-col bg-[#0b1020] text-[#e6ebff]">
      <header className="flex items-center gap-4 border-b border-[#263252] bg-[#131a2e] px-5 py-3">
        <span className="text-xl text-[#5b8cff]">&#9670;</span>
        <div>
          <h1 className="text-lg font-semibold leading-tight">AUTOMATElab Studio</h1>
          <p className="text-xs text-[#8b96b8]">No-Code Lab Orchestrator &middot; M1 Canvas</p>
        </div>
      </header>
      <ReactFlowProvider>
        <div className="flex flex-1 overflow-hidden">
          <Palette />
          <Canvas />
        </div>
      </ReactFlowProvider>
    </div>
  )
}
