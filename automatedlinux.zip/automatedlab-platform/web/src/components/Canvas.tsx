import { useCallback, useRef } from 'react'
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  type ReactFlowInstance,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { useStudio } from '../store'
import { nodeTypes } from './nodes'
import type { LabNode, NodeKind } from '../types'

let seq = 0

interface DropPayload {
  kind: NodeKind
  label: string
  os?: string
  services?: string[]
}

export default function Canvas() {
  const nodes = useStudio((s) => s.nodes)
  const edges = useStudio((s) => s.edges)
  const onNodesChange = useStudio((s) => s.onNodesChange)
  const onEdgesChange = useStudio((s) => s.onEdgesChange)
  const onConnect = useStudio((s) => s.onConnect)
  const addNode = useStudio((s) => s.addNode)

  const flow = useRef<ReactFlowInstance<LabNode> | null>(null)

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      const raw = e.dataTransfer.getData('application/automatelab-node')
      if (!raw || !flow.current) return
      const payload = JSON.parse(raw) as DropPayload
      const position = flow.current.screenToFlowPosition({ x: e.clientX, y: e.clientY })
      const node: LabNode = {
        id: `node_${++seq}`,
        type: payload.kind,
        position,
        data: { label: payload.label, os: payload.os, services: payload.services },
      }
      addNode(node)
    },
    [addNode],
  )

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = 'move'
  }, [])

  return (
    <div className="flex-1" onDrop={onDrop} onDragOver={onDragOver}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={nodeTypes}
        onInit={(inst) => (flow.current = inst)}
        fitView
      >
        <Background />
        <Controls />
        <MiniMap />
      </ReactFlow>
    </div>
  )
}
