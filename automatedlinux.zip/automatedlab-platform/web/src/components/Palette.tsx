import type { NodeKind } from '../types'

interface PaletteItemDef {
  kind: NodeKind
  label: string
  os?: string
  services?: string[]
}

const ITEMS: PaletteItemDef[] = [
  { kind: 'vmNode', label: 'Windows Server', os: 'Windows Server 2022' },
  { kind: 'vmNode', label: 'Windows 11', os: 'Windows 11 Enterprise' },
  { kind: 'vmNode', label: 'Ubuntu', os: 'Ubuntu 24.04' },
  { kind: 'vSwitchNode', label: 'vSwitch' },
  { kind: 'vSwitchNode', label: 'Gateway' },
  { kind: 'containerNode', label: 'PostgreSQL', services: ['postgres'] },
  { kind: 'containerNode', label: 'Redis', services: ['redis'] },
  { kind: 'containerNode', label: 'NGINX', services: ['nginx'] },
]

export default function Palette() {
  return (
    <aside className="w-56 shrink-0 overflow-auto border-r border-[#263252] bg-[#131a2e] p-4">
      <h2 className="mb-3 text-xs uppercase tracking-widest text-[#8b96b8]">Palette</h2>

      <Section title="Compute" items={ITEMS.filter((i) => i.kind === 'vmNode')} />
      <Section title="Network" items={ITEMS.filter((i) => i.kind === 'vSwitchNode')} />
      <Section title="Containers" items={ITEMS.filter((i) => i.kind === 'containerNode')} />
    </aside>
  )
}

function Section({ title, items }: { title: string; items: PaletteItemDef[] }) {
  return (
    <>
      <h3 className="mb-1 mt-3 text-xs text-[#5b8cff]">{title}</h3>
      {items.map((item) => (
        <PaletteItem key={item.label} {...item} />
      ))}
    </>
  )
}

function PaletteItem({ kind, label, os, services }: PaletteItemDef) {
  const onDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('application/automatelab-node', JSON.stringify({ kind, label, os, services }))
    e.dataTransfer.effectAllowed = 'move'
  }

  return (
    <div
      draggable
      onDragStart={onDragStart}
      className="mb-1 cursor-grab rounded-lg border border-[#263252] bg-[#1a2340] px-3 py-2 text-sm hover:border-[#5b8cff]"
    >
      {label}
    </div>
  )
}
