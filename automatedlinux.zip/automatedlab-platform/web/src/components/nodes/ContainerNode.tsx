import { Handle, Position } from '@xyflow/react'
import type { NodeProps } from '@xyflow/react'
import type { LabNode } from '../../types'

export default function ContainerNode({ data }: NodeProps<LabNode>) {
  return (
    <div className="min-w-[150px] rounded-xl border border-[#fbbf24] bg-[#131a2e] px-4 py-3 text-sm shadow-lg">
      <div className="font-semibold text-[#fbbf24]">{data.label}</div>
      {data.services && data.services.length > 0 && (
        <div className="text-xs text-[#8b96b8]">{data.services.join(', ')}</div>
      )}
      <Handle type="target" position={Position.Left} />
      <Handle type="source" position={Position.Right} />
    </div>
  )
}
