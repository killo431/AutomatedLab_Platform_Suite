import { Handle, Position } from '@xyflow/react'
import type { NodeProps } from '@xyflow/react'
import type { LabNode } from '../../types'

export default function SwitchNode({ data }: NodeProps<LabNode>) {
  return (
    <div className="min-w-[150px] rounded-lg border border-[#34d399] bg-[#131a2e] px-4 py-3 text-sm shadow-lg">
      <div className="font-semibold text-[#34d399]">{data.label}</div>
      <Handle type="target" position={Position.Top} />
      <Handle type="source" position={Position.Bottom} />
    </div>
  )
}
