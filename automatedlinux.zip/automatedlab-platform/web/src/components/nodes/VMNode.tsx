import { Handle, Position } from '@xyflow/react'
import type { NodeProps } from '@xyflow/react'
import type { LabNode } from '../../types'

export default function VMNode({ data }: NodeProps<LabNode>) {
  return (
    <div className="min-w-[150px] rounded-xl border border-[#5b8cff] bg-[#131a2e] px-4 py-3 text-sm shadow-lg">
      <div className="font-semibold">{data.label}</div>
      {data.os && <div className="text-xs text-[#8b96b8]">{data.os}</div>}
      {data.ipAddress && <div className="text-xs text-[#34d399]">{data.ipAddress}</div>}
      <Handle type="target" position={Position.Left} />
      <Handle type="source" position={Position.Right} />
    </div>
  )
}
