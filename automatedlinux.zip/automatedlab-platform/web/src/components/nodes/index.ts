import type { NodeTypes } from '@xyflow/react'
import VMNode from './VMNode'
import SwitchNode from './SwitchNode'
import ContainerNode from './ContainerNode'

export const nodeTypes = {
  vmNode: VMNode,
  vSwitchNode: SwitchNode,
  containerNode: ContainerNode,
} as NodeTypes
