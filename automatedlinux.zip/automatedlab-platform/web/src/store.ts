import { create } from 'zustand'
import { applyNodeChanges, applyEdgeChanges } from '@xyflow/react'
import type { NodeChange, EdgeChange, Edge, Connection } from '@xyflow/react'
import type { LabNode } from './types'

let edgeSeq = 0

interface StudioState {
  nodes: LabNode[]
  edges: Edge[]
  onNodesChange: (changes: NodeChange<LabNode>[]) => void
  onEdgesChange: (changes: EdgeChange[]) => void
  onConnect: (connection: Connection) => void
  addNode: (node: LabNode) => void
}

export const useStudio = create<StudioState>((set) => ({
  nodes: [],
  edges: [],
  onNodesChange: (changes) => set((s) => ({ nodes: applyNodeChanges(changes, s.nodes) })),
  onEdgesChange: (changes) => set((s) => ({ edges: applyEdgeChanges(changes, s.edges) })),
  onConnect: (connection) =>
    set((s) => ({ edges: [...s.edges, { ...connection, id: `e${++edgeSeq}` } as Edge] })),
  addNode: (node) => set((s) => ({ nodes: [...s.nodes, node] })),
}))
