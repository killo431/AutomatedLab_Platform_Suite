import type { Node } from '@xyflow/react'

export type NodeKind = 'vmNode' | 'vSwitchNode' | 'containerNode'

export interface LabNodeData extends Record<string, unknown> {
  label: string
  os?: string
  ramMb?: number
  vCpu?: number
  ipAddress?: string
  roles?: string[]
  services?: string[]
}

export type LabNode = Node<LabNodeData, NodeKind>
